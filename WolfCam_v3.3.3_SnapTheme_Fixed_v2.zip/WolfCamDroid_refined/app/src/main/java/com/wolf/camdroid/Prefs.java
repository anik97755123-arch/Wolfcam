package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Prefs {
    private static final String NAME = "wolfcam_prefs";
    private static SharedPreferences sp;

    public static synchronized void init(Context ctx) {
        if (sp == null && ctx != null) {
            Context app = ctx.getApplicationContext();
            sp = (app != null ? app : ctx).getSharedPreferences(NAME, Context.MODE_PRIVATE);
        }
    }

    public static boolean getBool(String key, boolean def) {
        if (sp == null) return def;
        return sp.getBoolean(key, def);
    }

    public static void setBool(String key, boolean val) {
        if (sp == null) return;
        sp.edit().putBoolean(key, val).commit();
    }

    public static int getInt(String key, int def) {
        if (sp == null) return def;
        return sp.getInt(key, def);
    }

    public static void setInt(String key, int val) {
        if (sp == null) return;
        sp.edit().putInt(key, val).commit();
    }

    public static String getString(String key, String def) {
        if (sp == null) return def;
        return sp.getString(key, def);
    }

    public static void setString(String key, String val) {
        if (sp == null) return;
        sp.edit().putString(key, val).commit();
    }

    public static ArrayList<String> getMediaList() {
        if (sp == null) return new ArrayList<String>();
        Set<String> set = sp.getStringSet("media_list", new HashSet<String>());
        return new ArrayList<String>(set);
    }

    public static void saveMediaList(ArrayList<String> list) {
        if (sp == null) return;
        Set<String> set = new HashSet<String>(list);
        sp.edit().putStringSet("media_list", set).commit();
    }

    public static String getActiveMedia() {
        if (sp == null) return "";
        return sp.getString("active_media", "");
    }

    public static void setActiveMedia(String path) {
        if (sp == null) return;
        sp.edit().putString("active_media", path).commit();
    }

    // All settings default OFF after install
    public static boolean notifControl() { return getBool("notif_control", false); }
    public static boolean playSound() { return getBool("play_sound", false); }
    public static boolean micHook() { return getBool("mic_hook", false); }
    public static boolean randomPlay() { return getBool("random_play", false); }
    public static boolean privateDir() { return getBool("private_dir", false); }
    public static boolean disableToast() { return getBool("disable_toast", false); }
    public static boolean photoFake() { return getBool("photo_fake", false); }
    public static boolean floatButton() { return getBool("float_button", true); }

    public static boolean isFirstLaunchDone() { return getBool("first_launch_done", false); }
    public static void setFirstLaunchDone() { setBool("first_launch_done", true); }
    public static int getLaunchCount() { return getInt("launch_count", 0); }
    public static void incLaunchCount() { setInt("launch_count", getLaunchCount() + 1); }
}
