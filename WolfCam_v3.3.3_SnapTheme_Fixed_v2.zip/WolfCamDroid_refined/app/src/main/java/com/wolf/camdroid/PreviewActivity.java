package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Activity;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings("deprecation")
public class PreviewActivity extends Activity implements SurfaceHolder.Callback {

    private SurfaceView surfaceView;
    private SurfaceHolder holder;
    private Camera camera;
    private TextView tvHint;
    private boolean previewing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        LogHelper.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_preview);

        surfaceView = (SurfaceView) findViewById(R.id.surfacePreview);
        tvHint = (TextView) findViewById(R.id.tvPreviewHint);
        Button btnClose = (Button) findViewById(R.id.btnClosePreview);

        ThemeHelper.applyActivityTheme(this, -1);
        ThemeHelper.applyButton(btnClose, false);
        if (tvHint != null) {
            tvHint.setTextColor(ThemeHelper.getAccent());
        }

        holder = surfaceView.getHolder();
        holder.addCallback(this);
        if (Build.VERSION.SDK_INT < 11) {
            holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        }

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        boolean inj = CamMonitor.isInjected();
        tvHint.setText(inj
                ? "Virtual camera active — displaying injected stream"
                : "Phone camera preview (virtual camera off)");
    }

    @Override
    public void surfaceCreated(SurfaceHolder h) {
        openCamera();
        startPreviewSafe();
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int format, int width, int height) {
        if (camera == null) {
            openCamera();
        }
        startPreviewSafe();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        stopPreviewSafe();
        releaseCamera();
    }

    private void openCamera() {
        if (camera != null) return;
        Exception last = null;
        try {
            camera = Camera.open(0);
        } catch (Exception e) {
            last = e;
            try {
                camera = Camera.open();
            } catch (Exception e2) {
                last = e2;
                camera = null;
            }
        }
        if (camera == null) {
            String msg = last != null ? last.getMessage() : "unknown";
            String logPath = LogHelper.writeDetailedError(this, "PREVIEW_OPEN",
                    "Could not open Camera in PreviewActivity: " + msg, null, last);
            tvHint.setText("Cannot open camera: " + msg + "\nSaved: " + logPath);
            Toast.makeText(this, "Cannot open camera — error saved to /storage/emulated/0/wolfcam", Toast.LENGTH_LONG).show();
        }
    }

    private void startPreviewSafe() {
        if (camera == null || holder == null) return;
        try {
            if (previewing) {
                try { camera.stopPreview(); } catch (Exception ignored) {}
                previewing = false;
            }

            Camera.Parameters params = camera.getParameters();
            try {
                Camera.Size best = null;
                int target = 640;
                for (Camera.Size s : params.getSupportedPreviewSizes()) {
                    if (s.width <= 1280 && s.height <= 720) {
                        if (best == null || Math.abs(s.width - target) < Math.abs(best.width - target)) {
                            best = s;
                        }
                    }
                }
                if (best == null) {
                    best = params.getSupportedPreviewSizes().get(0);
                }
                params.setPreviewSize(best.width, best.height);
            } catch (Exception ignored) {}

            try {
                if (params.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                } else if (params.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                }
            } catch (Exception ignored) {}

            try {
                camera.setParameters(params);
            } catch (Exception ignored) {}

            setCameraDisplayOrientation();
            camera.setPreviewDisplay(holder);
            camera.startPreview();
            previewing = true;
            boolean inj = CamMonitor.isInjected();
            tvHint.setText(inj
                    ? "Preview running — virtual camera feed active"
                    : "Preview running — phone camera");
        } catch (Exception e) {
            String logPath = LogHelper.writeDetailedError(this, "PREVIEW_START", e.getMessage(), null, e);
            tvHint.setText("Preview error: " + e.getMessage() + "\nSaved: " + logPath);
            Toast.makeText(this, "Preview failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setCameraDisplayOrientation() {
        if (camera == null) return;
        try {
            int rotation = getWindowManager().getDefaultDisplay().getRotation();
            int degrees = 0;
            switch (rotation) {
                case Surface.ROTATION_0: degrees = 0; break;
                case Surface.ROTATION_90: degrees = 90; break;
                case Surface.ROTATION_180: degrees = 180; break;
                case Surface.ROTATION_270: degrees = 270; break;
            }
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(0, info);
            int result;
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                result = (info.orientation + degrees) % 360;
                result = (360 - result) % 360;
            } else {
                result = (info.orientation - degrees + 360) % 360;
            }
            camera.setDisplayOrientation(result);
        } catch (Exception e) {
            try {
                camera.setDisplayOrientation(90);
            } catch (Exception ignored) {}
        }
    }

    private void stopPreviewSafe() {
        if (camera != null && previewing) {
            try { camera.stopPreview(); } catch (Exception ignored) {}
            previewing = false;
        }
    }

    private void releaseCamera() {
        stopPreviewSafe();
        if (camera != null) {
            try { camera.release(); } catch (Exception ignored) {}
            camera = null;
        }
    }

    @Override
    protected void onPause() {
        stopPreviewSafe();
        releaseCamera();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        releaseCamera();
        super.onDestroy();
    }
}
