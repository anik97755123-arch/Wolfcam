package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.view.Surface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Locale;

/**
 * Prepares selected media files (both video and still images) into a valid MP4 video container
 * (wolf_source.mp4) compatible with Android 9 through Android 15+ hardware and software codecs.
 */
public class MediaHelper {

    public static File getCachedMediaFile(Context ctx) {
        return new File(ctx.getFilesDir(), "wolf_source.mp4");
    }

    public static boolean isImagePathOrMime(Context ctx, String pathOrUri) {
        if (pathOrUri == null) return false;
        String lower = pathOrUri.toLowerCase(Locale.US);
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")
                || lower.endsWith(".webp") || lower.endsWith(".bmp") || lower.endsWith(".gif")) {
            return true;
        }
        if (pathOrUri.startsWith("content://")) {
            try {
                String mime = ctx.getContentResolver().getType(Uri.parse(pathOrUri));
                if (mime != null && mime.startsWith("image/")) {
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    /**
     * Checks whether a file on disk is a valid video container with at least one video/* track.
     */
    public static boolean hasValidVideoTrack(File file) {
        if (file == null || !file.exists() || file.length() < 64) return false;
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(file.getAbsolutePath());
            int count = extractor.getTrackCount();
            for (int i = 0; i < count; i++) {
                MediaFormat fmt = extractor.getTrackFormat(i);
                String mime = fmt.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/")) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
        }
        return false;
    }

    /**
     * Ensures wolf_source.mp4 exists and is a valid video container for the currently selected active_media.
     */
    public static boolean ensureActiveMediaPrepared(Context ctx) {
        File cached = getCachedMediaFile(ctx);
        String active = Prefs.getActiveMedia();
        if (cached.exists() && cached.length() > 256 && hasValidVideoTrack(cached)) {
            return true;
        }
        if (active != null && !active.isEmpty()) {
            return prepareSourceToCache(ctx, active);
        }
        return cached.exists() && cached.length() > 256 && hasValidVideoTrack(cached);
    }

    /**
     * Copies a video file to wolf_source.mp4, or converts an image into a looping H.264 MP4 in wolf_source.mp4.
     */
    public static synchronized boolean prepareSourceToCache(Context ctx, String pathOrUri) {
        if (pathOrUri == null || pathOrUri.isEmpty()) return false;
        File outMp4 = getCachedMediaFile(ctx);
        File tmpRaw = new File(ctx.getFilesDir(), "wolf_raw_tmp.bin");
        try {
            if (!copyToFile(ctx, pathOrUri, tmpRaw)) {
                LogHelper.writeDetailedError(ctx, "MEDIA_COPY", "Could not read source file: " + pathOrUri, null, null);
                return false;
            }
            if (!isImagePathOrMime(ctx, pathOrUri) && hasValidVideoTrack(tmpRaw)) {
                copyFile(tmpRaw, outMp4);
                tmpRaw.delete();
                LogHelper.log("MEDIA", "Prepared video source (" + outMp4.length() + " bytes)");
                return true;
            }

            Bitmap bmp = decodeSampledBitmap(tmpRaw.getAbsolutePath(), 1920, 1920);
            tmpRaw.delete();
            if (bmp != null) {
                boolean encoded = encodeBitmapToMp4(ctx, bmp, outMp4);
                bmp.recycle();
                if (encoded && hasValidVideoTrack(outMp4)) {
                    LogHelper.log("MEDIA", "Converted image to MP4 (" + outMp4.length() + " bytes)");
                    return true;
                } else {
                    LogHelper.writeDetailedError(ctx, "MEDIA_ENCODE",
                            "Failed encoding still image to MP4 container for: " + pathOrUri, null, null);
                    return false;
                }
            } else {
                LogHelper.writeDetailedError(ctx, "MEDIA_DECODE",
                        "BitmapFactory could not decode image file: " + pathOrUri, null, null);
                return false;
            }
        } catch (Exception e) {
            LogHelper.writeDetailedError(ctx, "MEDIA_EXCEPTION", "Error preparing media: " + pathOrUri, null, e);
            try { tmpRaw.delete(); } catch (Exception ignored) {}
            return false;
        }
    }

    private static Bitmap decodeSampledBitmap(String path, int reqW, int reqH) {
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, opts);
            int w = opts.outWidth;
            int h = opts.outHeight;
            if (w <= 0 || h <= 0) return null;
            int inSampleSize = 1;
            while ((w / inSampleSize) > reqW || (h / inSampleSize) > reqH) {
                inSampleSize *= 2;
            }
            BitmapFactory.Options decodeOpts = new BitmapFactory.Options();
            decodeOpts.inSampleSize = inSampleSize;
            decodeOpts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(path, decodeOpts);
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean copyToFile(Context ctx, String pathOrUri, File dest) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            if (pathOrUri.startsWith("content://")) {
                in = ctx.getContentResolver().openInputStream(Uri.parse(pathOrUri));
            } else {
                File f = new File(pathOrUri);
                if (!f.exists()) return false;
                in = new FileInputStream(f);
            }
            if (in == null) return false;
            out = new FileOutputStream(dest);
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.flush();
            return dest.length() > 0;
        } catch (Exception e) {
            LogHelper.logError("COPY", e);
            return false;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    private static void copyFile(File src, File dst) throws Exception {
        FileInputStream in = new FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        try {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.flush();
        } finally {
            try { in.close(); } catch (Exception ignored) {}
            try { out.close(); } catch (Exception ignored) {}
        }
    }

    /**
     * Encodes a still Bitmap into a 2-second 15fps H.264 MP4 file (1280x720) using multi-strategy
     * fallback (Flexible YUV420 Image planes -> SemiPlanar/Planar ByteBuffer -> Surface) for
     * universal compatibility from Android 9 (API 28) through Android 15 (API 35).
     */
    private static boolean encodeBitmapToMp4(Context ctx, Bitmap src, File outFile) {
        final int width = 1280;
        final int height = 720;
        final int fps = 15;
        final int totalFrames = 30;

        Bitmap scaled = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(scaled);
        canvas.drawColor(Color.BLACK);

        float srcW = src.getWidth();
        float srcH = src.getHeight();
        float scale = Math.min((float) width / srcW, (float) height / srcH);
        float dstW = srcW * scale;
        float dstH = srcH * scale;
        float left = (width - dstW) / 2f;
        float top = (height - dstH) / 2f;
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        canvas.drawBitmap(src, null, new RectF(left, top, left + dstW, top + dstH), paint);

        try {
            if (Build.VERSION.SDK_INT >= 21 && encodeWithFlexibleImage(scaled, outFile, width, height, fps, totalFrames)) {
                if (hasValidVideoTrack(outFile)) return true;
            }
            if (encodeWithByteBuffer(scaled, outFile, width, height, fps, totalFrames,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar, true)) {
                if (hasValidVideoTrack(outFile)) return true;
            }
            if (encodeWithByteBuffer(scaled, outFile, width, height, fps, totalFrames,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar, false)) {
                if (hasValidVideoTrack(outFile)) return true;
            }
            if (encodeWithSurface(scaled, outFile, width, height, fps, totalFrames)) {
                if (hasValidVideoTrack(outFile)) return true;
            }
            return false;
        } finally {
            scaled.recycle();
        }
    }

    private static boolean encodeWithFlexibleImage(Bitmap frameBmp, File outFile, int width, int height, int fps, int totalFrames) {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean muxerStarted = false;
        try {
            if (outFile.exists()) outFile.delete();
            int[] argb = new int[width * height];
            frameBmp.getPixels(argb, 0, width, 0, 0, width, height);
            byte[] yPlane = new byte[width * height];
            byte[] uPlane = new byte[(width / 2) * (height / 2)];
            byte[] vPlane = new byte[(width / 2) * (height / 2)];
            fillPlanarYUV(argb, width, height, yPlane, uPlane, vPlane);

            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            format.setInteger(MediaFormat.KEY_BIT_RATE, 2500000);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            muxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            int trackIndex = -1;

            for (int i = 0; i < totalFrames; i++) {
                int inIdx = encoder.dequeueInputBuffer(20000);
                if (inIdx >= 0) {
                    Image img = encoder.getInputImage(inIdx);
                    if (img != null) {
                        writePlanesToImage(img, width, height, yPlane, uPlane, vPlane);
                        long ptsUs = (i * 1000000L) / fps;
                        encoder.queueInputBuffer(inIdx, 0, width * height * 3 / 2, ptsUs, 0);
                    } else {
                        return false;
                    }
                }
                trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, false);
                if (trackIndex >= 0) muxerStarted = true;
            }
            int inIdx = encoder.dequeueInputBuffer(20000);
            if (inIdx >= 0) {
                long ptsUs = (totalFrames * 1000000L) / fps;
                encoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, true);
            if (trackIndex >= 0) muxerStarted = true;
            return muxerStarted && outFile.exists() && outFile.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
            try {
                if (muxer != null) {
                    if (muxerStarted) muxer.stop();
                    muxer.release();
                }
            } catch (Exception ignored) {}
        }
    }

    private static void writePlanesToImage(Image img, int width, int height, byte[] ySrc, byte[] uSrc, byte[] vSrc) {
        Image.Plane[] planes = img.getPlanes();
        if (planes == null || planes.length < 3) return;

        // Y plane
        ByteBuffer yBuf = planes[0].getBuffer();
        int yRowStride = planes[0].getRowStride();
        int yPixStride = planes[0].getPixelStride();
        for (int row = 0; row < height; row++) {
            int dstRowStart = row * yRowStride;
            int srcRowStart = row * width;
            if (yPixStride == 1) {
                yBuf.position(dstRowStart);
                yBuf.put(ySrc, srcRowStart, width);
            } else {
                for (int col = 0; col < width; col++) {
                    yBuf.put(dstRowStart + col * yPixStride, ySrc[srcRowStart + col]);
                }
            }
        }

        // U and V planes
        int uvW = width / 2;
        int uvH = height / 2;
        for (int p = 1; p <= 2; p++) {
            byte[] src = (p == 1) ? uSrc : vSrc;
            ByteBuffer buf = planes[p].getBuffer();
            int rowStride = planes[p].getRowStride();
            int pixStride = planes[p].getPixelStride();
            int cap = buf.capacity();
            for (int row = 0; row < uvH; row++) {
                int dstRowStart = row * rowStride;
                int srcRowStart = row * uvW;
                for (int col = 0; col < uvW; col++) {
                    int dstIdx = dstRowStart + col * pixStride;
                    if (dstIdx >= 0 && dstIdx < cap) {
                        buf.put(dstIdx, src[srcRowStart + col]);
                    }
                }
            }
        }
    }

    private static boolean encodeWithByteBuffer(Bitmap frameBmp, File outFile, int width, int height, int fps, int totalFrames, int colorFormat, boolean semiPlanar) {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean muxerStarted = false;
        try {
            if (outFile.exists()) outFile.delete();
            byte[] yuv = semiPlanar ? bitmapToNV12(frameBmp, width, height) : bitmapToI420(frameBmp, width, height);

            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
            format.setInteger(MediaFormat.KEY_BIT_RATE, 2500000);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            muxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            int trackIndex = -1;
            ByteBuffer[] inputBuffers = encoder.getInputBuffers();

            for (int i = 0; i < totalFrames; i++) {
                int inIdx = encoder.dequeueInputBuffer(20000);
                if (inIdx >= 0) {
                    ByteBuffer buf = (Build.VERSION.SDK_INT >= 21) ? encoder.getInputBuffer(inIdx) : inputBuffers[inIdx];
                    if (buf != null) {
                        buf.clear();
                        int len = Math.min(buf.remaining(), yuv.length);
                        buf.put(yuv, 0, len);
                        long ptsUs = (i * 1000000L) / fps;
                        encoder.queueInputBuffer(inIdx, 0, len, ptsUs, 0);
                    }
                }
                trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, false);
                if (trackIndex >= 0) muxerStarted = true;
            }
            int inIdx = encoder.dequeueInputBuffer(20000);
            if (inIdx >= 0) {
                long ptsUs = (totalFrames * 1000000L) / fps;
                encoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, true);
            if (trackIndex >= 0) muxerStarted = true;
            return muxerStarted && outFile.exists() && outFile.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
            try {
                if (muxer != null) {
                    if (muxerStarted) muxer.stop();
                    muxer.release();
                }
            } catch (Exception ignored) {}
        }
    }

    private static boolean encodeWithSurface(Bitmap frameBmp, File outFile, int width, int height, int fps, int totalFrames) {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        Surface inputSurface = null;
        boolean muxerStarted = false;
        try {
            if (outFile.exists()) outFile.delete();
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            format.setInteger(MediaFormat.KEY_BIT_RATE, 2500000);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType("video/avc");
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            inputSurface = encoder.createInputSurface();
            encoder.start();

            muxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            int trackIndex = -1;

            for (int i = 0; i < totalFrames; i++) {
                Canvas c = inputSurface.lockCanvas(new Rect(0, 0, width, height));
                c.drawBitmap(frameBmp, 0f, 0f, null);
                inputSurface.unlockCanvasAndPost(c);
                trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, false);
                if (trackIndex >= 0) muxerStarted = true;
                try { Thread.sleep(20); } catch (InterruptedException ignored) {}
            }
            encoder.signalEndOfInputStream();
            trackIndex = drainEncoder(encoder, muxer, bufferInfo, trackIndex, true);
            if (trackIndex >= 0) muxerStarted = true;
            return muxerStarted && outFile.exists() && outFile.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (inputSurface != null) inputSurface.release(); } catch (Exception ignored) {}
            try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
            try {
                if (muxer != null) {
                    if (muxerStarted) muxer.stop();
                    muxer.release();
                }
            } catch (Exception ignored) {}
        }
    }

    private static int drainEncoder(MediaCodec encoder, MediaMuxer muxer, MediaCodec.BufferInfo bufferInfo, int trackIndex, boolean endOfStream) {
        ByteBuffer[] outputBuffers = encoder.getOutputBuffers();
        int retries = 0;
        int maxRetries = endOfStream ? 100 : 2;
        while (true) {
            int status = encoder.dequeueOutputBuffer(bufferInfo, 10000);
            if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) {
                    break;
                }
                retries++;
                if (retries >= maxRetries) {
                    break;
                }
            } else if (status == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                outputBuffers = encoder.getOutputBuffers();
            } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (trackIndex < 0) {
                    MediaFormat newFormat = encoder.getOutputFormat();
                    trackIndex = muxer.addTrack(newFormat);
                    muxer.start();
                }
            } else if (status >= 0) {
                ByteBuffer encodedData = (Build.VERSION.SDK_INT >= 21) ? encoder.getOutputBuffer(status) : outputBuffers[status];
                if (encodedData != null) {
                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0;
                    }
                    if (bufferInfo.size != 0 && trackIndex >= 0) {
                        encodedData.position(bufferInfo.offset);
                        encodedData.limit(bufferInfo.offset + bufferInfo.size);
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo);
                    }
                }
                encoder.releaseOutputBuffer(status, false);
                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break;
                }
            }
        }
        return trackIndex;
    }

    private static void fillPlanarYUV(int[] argb, int width, int height, byte[] yOut, byte[] uOut, byte[] vOut) {
        int yIndex = 0;
        int uvIndex = 0;
        int index = 0;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[index++];
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;

                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                yOut[yIndex++] = (byte) (y < 0 ? 0 : (y > 255 ? 255 : y));
                if (j % 2 == 0 && i % 2 == 0) {
                    uOut[uvIndex] = (byte) (u < 0 ? 0 : (u > 255 ? 255 : u));
                    vOut[uvIndex] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : v));
                    uvIndex++;
                }
            }
        }
    }

    private static byte[] bitmapToNV12(Bitmap bmp, int width, int height) {
        int[] argb = new int[width * height];
        bmp.getPixels(argb, 0, width, 0, 0, width, height);
        byte[] yuv = new byte[width * height * 3 / 2];
        int yIndex = 0;
        int uvIndex = width * height;
        int index = 0;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[index++];
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;

                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                yuv[yIndex++] = (byte) (y < 0 ? 0 : (y > 255 ? 255 : y));
                if (j % 2 == 0 && i % 2 == 0) {
                    yuv[uvIndex++] = (byte) (u < 0 ? 0 : (u > 255 ? 255 : u));
                    yuv[uvIndex++] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : v));
                }
            }
        }
        return yuv;
    }

    private static byte[] bitmapToI420(Bitmap bmp, int width, int height) {
        int[] argb = new int[width * height];
        bmp.getPixels(argb, 0, width, 0, 0, width, height);
        byte[] yuv = new byte[width * height * 3 / 2];
        int frameSize = width * height;
        int yIndex = 0;
        int uIndex = frameSize;
        int vIndex = frameSize + (frameSize / 4);
        int index = 0;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[index++];
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;

                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                yuv[yIndex++] = (byte) (y < 0 ? 0 : (y > 255 ? 255 : y));
                if (j % 2 == 0 && i % 2 == 0) {
                    yuv[uIndex++] = (byte) (u < 0 ? 0 : (u > 255 ? 255 : u));
                    yuv[vIndex++] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : v));
                }
            }
        }
        return yuv;
    }
}
