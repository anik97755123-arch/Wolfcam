package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.ArrayList;

public class ManageActivity extends Activity {

    private static final int PICK_MEDIA_REQ = 3003;

    private ListView listMedia;
    private TextView tvTotalStats;
    private Button btnAdd, btnPreview;
    private MediaAdapter adapter;
    private ArrayList<String> mediaList;
    private File mediaDir;
    private int selectedPos = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        LogHelper.init(this);
        setContentView(R.layout.activity_manage);

        listMedia = (ListView) findViewById(R.id.listMedia);
        tvTotalStats = (TextView) findViewById(R.id.tvTotalStats);
        btnAdd = (Button) findViewById(R.id.btnAddFile);
        btnPreview = (Button) findViewById(R.id.btnPreview);

        applyScreenTheme();

        mediaDir = new File(getFilesDir(), "media");
        if (!mediaDir.exists()) mediaDir.mkdirs();

        mediaList = Prefs.getMediaList();
        ArrayList<String> cleaned = new ArrayList<String>();
        for (String p : mediaList) {
            if (p != null && new File(p).exists()) cleaned.add(p);
        }
        if (cleaned.size() != mediaList.size()) {
            mediaList = cleaned;
            Prefs.saveMediaList(mediaList);
        }

        String active = Prefs.getActiveMedia();
        if (active != null && !active.isEmpty()) {
            selectedPos = mediaList.indexOf(active);
            if (selectedPos < 0 && new File(active).exists()) {
                mediaList.add(active);
                Prefs.saveMediaList(mediaList);
                selectedPos = mediaList.size() - 1;
            }
        }

        adapter = new MediaAdapter(this, mediaList);
        listMedia.setAdapter(adapter);
        updateStats();

        listMedia.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ThemeHelper.triggerHaptic(view);
                selectedPos = position;
                final String path = mediaList.get(position);
                Prefs.setActiveMedia(path);
                adapter.notifyDataSetChanged();
                toast("Selected: " + displayName(path));
                prepareCacheAsync(path);
            }
        });

        listMedia.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                ThemeHelper.triggerHaptic(view);
                AlertDialog dialog = new AlertDialog.Builder(ManageActivity.this)
                        .setTitle("Remove media")
                        .setMessage("Remove \"" + displayName(mediaList.get(position)) + "\"?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String removed = mediaList.remove(position);
                                try {
                                    File f = new File(removed);
                                    if (f.exists() && f.getAbsolutePath().startsWith(mediaDir.getAbsolutePath())) {
                                        f.delete();
                                    }
                                } catch (Exception ignored) {}
                                Prefs.saveMediaList(mediaList);
                                if (removed.equals(Prefs.getActiveMedia())) {
                                    Prefs.setActiveMedia("");
                                    selectedPos = -1;
                                } else if (selectedPos == position) {
                                    selectedPos = -1;
                                } else if (selectedPos > position) {
                                    selectedPos--;
                                }
                                adapter.notifyDataSetChanged();
                                updateStats();
                                toast("Removed");
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog.show();
                try {
                    dialog.getWindow().setBackgroundDrawable(ThemeHelper.dialogBg());
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ThemeHelper.getDanger());
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ThemeHelper.getAccent());
                } catch (Exception ignored) {}
                return true;
            }
        });

        btnPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                if (selectedPos < 0 || selectedPos >= mediaList.size()) {
                    toast("Select a file first");
                    return;
                }
                showPreviewDialog(mediaList.get(selectedPos));
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
                startActivityForResult(intent, PICK_MEDIA_REQ);
            }
        });

        findViewById(R.id.navHome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        findViewById(R.id.navSettings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                startActivity(new Intent(ManageActivity.this, SettingsActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyScreenTheme();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void applyScreenTheme() {
        ThemeHelper.applyActivityTheme(this, 1);
        ThemeHelper.applySoftButton(btnPreview);
        ThemeHelper.applyButton(btnAdd, false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_MEDIA_REQ || resultCode != RESULT_OK || data == null) return;
        final Uri uri = data.getData();
        if (uri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        final String mime = getContentResolver().getType(uri);
        final boolean isVideo = mime != null && mime.startsWith("video");
        final String ext = isVideo ? ".mp4" : guessImageExt(mime);
        final String localName = "media_" + System.currentTimeMillis() + ext;
        final File dest = new File(mediaDir, localName);

        toast("Importing & preparing media...");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream in = getContentResolver().openInputStream(uri);
                    if (in == null) throw new Exception("Cannot open input stream for URI: " + uri);
                    OutputStream out = new FileOutputStream(dest);
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                    in.close();
                    out.close();

                    final String path = dest.getAbsolutePath();
                    final boolean prepared = MediaHelper.prepareSourceToCache(ManageActivity.this, path);
                    CamMonitor.reloadActiveMediaIfInjected(ManageActivity.this);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!mediaList.contains(path)) {
                                mediaList.add(path);
                                Prefs.saveMediaList(mediaList);
                            }
                            selectedPos = mediaList.indexOf(path);
                            Prefs.setActiveMedia(path);
                            adapter.notifyDataSetChanged();
                            updateStats();
                            if (prepared) {
                                toast("Added & ready: " + displayName(path) + (isVideo ? " (Video)" : " (Image)"));
                            } else {
                                toast("Added (check error log in /storage/emulated/0/wolfcam)");
                            }
                        }
                    });
                } catch (Exception e) {
                    LogHelper.writeDetailedError(ManageActivity.this, "MEDIA_IMPORT", e.getMessage(), null, e);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toast("Failed to import media — error saved to /storage/emulated/0/wolfcam");
                        }
                    });
                }
            }
        }).start();
    }

    private void prepareCacheAsync(final String srcPath) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                MediaHelper.prepareSourceToCache(ManageActivity.this, srcPath);
                CamMonitor.reloadActiveMediaIfInjected(ManageActivity.this);
            }
        }).start();
    }

    private void showPreviewDialog(String path) {
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setPadding(16, 16, 16, 16);
        Bitmap bmp = loadFullBitmap(path);
        if (bmp != null) {
            iv.setImageBitmap(bmp);
        } else {
            try {
                bmp = ThumbnailUtils.createVideoThumbnail(path, MediaStore.Images.Thumbnails.FULL_SCREEN_KIND);
            } catch (Exception ignored) {}
            if (bmp != null) iv.setImageBitmap(bmp);
            else iv.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(displayName(path) + "  •  " + detectType(path));
        b.setView(iv);
        b.setPositiveButton("OK", null);
        AlertDialog d = b.create();
        d.show();
        try {
            d.getWindow().setBackgroundDrawable(ThemeHelper.dialogBg());
            d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ThemeHelper.getAccent());
        } catch (Exception ignored) {}
    }

    private static Bitmap loadFullBitmap(String path) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            int w = bounds.outWidth;
            int h = bounds.outHeight;
            if (w <= 0 || h <= 0) return null;
            int sample = 1;
            int maxSide = Math.max(w, h);
            while (maxSide / sample > 2048) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(path, opts);
        } catch (Exception e) {
            return null;
        }
    }

    private static Bitmap loadThumb(String path, boolean video) {
        try {
            if (video) {
                return ThumbnailUtils.createVideoThumbnail(path, MediaStore.Images.Thumbnails.MINI_KIND);
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 4;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeFile(path, opts);
            if (bmp != null) return ThumbnailUtils.extractThumbnail(bmp, 128, 128);
        } catch (Exception ignored) {}
        return null;
    }

    private void updateStats() {
        long total = 0;
        for (String p : mediaList) {
            File f = new File(p);
            if (f.exists()) total += f.length();
        }
        tvTotalStats.setText(mediaList.size() + " files • " + formatSize(total));
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.2f MB", bytes / (1024.0 * 1024.0));
    }

    private static String guessImageExt(String mime) {
        if (mime == null) return ".jpg";
        if (mime.contains("png")) return ".png";
        if (mime.contains("webp")) return ".webp";
        if (mime.contains("gif")) return ".gif";
        return ".jpg";
    }

    static String displayName(String path) {
        if (path == null || path.isEmpty()) return "Unknown";
        String name = path;
        int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf(':'));
        if (slash >= 0 && slash < path.length() - 1) name = path.substring(slash + 1);
        try {
            name = URLDecoder.decode(name, "UTF-8");
        } catch (Exception ignored) {}
        if (name.startsWith("media_") && name.length() > 10) {
            String ext = "";
            int dot = name.lastIndexOf('.');
            if (dot > 0) ext = name.substring(dot);
            name = "Item " + name.substring(6, Math.min(13, name.length())) + ext;
        }
        if (name.length() > 36) name = name.substring(0, 33) + "...";
        return name;
    }

    static String detectType(String path) {
        if (path == null) return "Media";
        String n = path.toLowerCase();
        if (n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".webm")
                || n.endsWith(".3gp") || n.endsWith(".avi") || n.endsWith(".mov")) {
            return "Video";
        }
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")
                || n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp")) {
            return "Image";
        }
        return "Media";
    }

    private void toast(String msg) {
        if (!Prefs.getBool("disable_toast", false)) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        }
    }

    class MediaAdapter extends BaseAdapter {
        private Context ctx;
        private ArrayList<String> data;
        private LayoutInflater inflater;

        MediaAdapter(Context c, ArrayList<String> list) {
            ctx = c;
            data = list;
            inflater = LayoutInflater.from(c);
        }

        @Override
        public int getCount() { return data.size(); }

        @Override
        public Object getItem(int position) { return data.get(position); }

        @Override
        public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = inflater.inflate(R.layout.item_media, parent, false);
            }
            ImageView ivThumb = (ImageView) v.findViewById(R.id.ivThumb);
            TextView tvName = (TextView) v.findViewById(R.id.tvName);
            TextView tvType = (TextView) v.findViewById(R.id.tvType);
            RadioButton rb = (RadioButton) v.findViewById(R.id.rbSelect);

            final String path = data.get(position);
            final String type = detectType(path);
            boolean isSel = (position == selectedPos);

            tvName.setText(displayName(path));
            tvName.setTextColor(isSel ? ThemeHelper.getAccent() : Color.parseColor("#F8FAFC"));
            tvType.setText(type + (isSel ? "  •  Active" : ""));
            tvType.setTextColor(isSel ? ThemeHelper.getAccent() : Color.parseColor("#94A3B8"));
            rb.setChecked(isSel);
            if (Build.VERSION.SDK_INT >= 21) {
                rb.setButtonTintList(ColorStateList.valueOf(isSel ? ThemeHelper.getAccent() : Color.parseColor("#64748B")));
            }

            if (isSel) {
                GradientDrawable hl = new GradientDrawable();
                hl.setColor(ThemeHelper.getAccentAlpha(28));
                v.setBackgroundDrawable(hl);
            } else {
                v.setBackgroundDrawable(null);
            }

            Bitmap thumb = loadThumb(path, "Video".equals(type));
            if (thumb != null) {
                ivThumb.setImageBitmap(thumb);
            } else if ("Video".equals(type)) {
                ivThumb.setImageResource(android.R.drawable.ic_media_play);
            } else {
                ivThumb.setImageResource(android.R.drawable.ic_menu_gallery);
            }
            return v;
        }
    }
}
