package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class WolfFloatService extends Service {

    private WindowManager windowManager;
    private LinearLayout rootLayout;
    private View floatView;
    private LinearLayout panel;
    private WindowManager.LayoutParams params;
    private boolean panelOpen = false;
    private Handler handler = new Handler();
    private boolean monitoring = true;
    private PowerManager.WakeLock wakeLock;
    private long lastActionMs = 0;
    private Toast currentToast;
    private BroadcastReceiver stateReceiver;

    private TextView tvFloatStatus;
    private Button btnFloatInject, btnFloatMute, btnOpen, btnExit;
    private TextView bubble;
    private int screenW = 1080;
    private int screenH = 1920;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.init(this);
        LogHelper.init(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            Display d = windowManager.getDefaultDisplay();
            Point size = new Point();
            if (Build.VERSION.SDK_INT >= 13) {
                d.getSize(size);
                screenW = size.x;
                screenH = size.y;
            } else {
                screenW = d.getWidth();
                screenH = d.getHeight();
            }
        } catch (Exception ignored) {}

        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WolfCam:KeepAlive");
                wakeLock.setReferenceCounted(false);
                if (!wakeLock.isHeld()) wakeLock.acquire(60 * 60 * 1000L);
            }
        } catch (Exception e) {
            LogHelper.logError("WAKE", e);
        }

        stateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshPanelStatus();
                    }
                });
            }
        };
        try {
            registerReceiver(stateReceiver, new IntentFilter(CamMonitor.ACTION_STATE_CHANGED));
        } catch (Exception ignored) {}

        createFloatButton();
        startMonitor();
        CamMonitor.updateNotification(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!Prefs.getBool("float_button", true)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        monitoring = true;
        refreshPanelStatus();
        return START_STICKY;
    }

    private boolean debounce() {
        long now = SystemClock.uptimeMillis();
        if (now - lastActionMs < 450) return false;
        lastActionMs = now;
        return true;
    }

    private void toast(String msg) {
        if (Prefs.getBool("disable_toast", false)) return;
        try {
            if (currentToast != null) currentToast.cancel();
            currentToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
            currentToast.show();
        } catch (Exception ignored) {}
    }

    private int windowType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void createFloatButton() {
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setPadding(10, 10, 10, 10);

        bubble = new TextView(this);
        bubble.setText(" W ");
        bubble.setTextSize(19);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(30, 22, 30, 22);
        rootLayout.addView(bubble);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(View.GONE);
        panel.setPadding(18, 16, 18, 16);
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        panelLp.topMargin = 8;
        panel.setLayoutParams(panelLp);

        tvFloatStatus = new TextView(this);
        tvFloatStatus.setTextColor(0xFF94A3B8);
        tvFloatStatus.setTextSize(11.5f);
        tvFloatStatus.setTypeface(Typeface.DEFAULT_BOLD);
        tvFloatStatus.setPadding(8, 4, 8, 12);
        tvFloatStatus.setText("Checking...");
        panel.addView(tvFloatStatus);

        btnFloatInject = makeBtn("Start Virtual Cam");
        panel.addView(btnFloatInject);
        btnFloatMute = makeBtn("Mute Mic");
        panel.addView(btnFloatMute);
        btnOpen = makeBtn("Open App");
        panel.addView(btnOpen);
        btnExit = makeBtn("Exit App");
        panel.addView(btnExit);

        rootLayout.addView(panel);
        floatView = rootLayout;

        int savedX = Prefs.getInt("float_x", 24);
        int savedY = Prefs.getInt("float_y", 220);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                windowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = savedX;
        params.y = savedY;

        try {
            windowManager.addView(floatView, params);
        } catch (Exception e) {
            LogHelper.logError("FLOAT", e);
            stopSelf();
            return;
        }

        floatView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE && panelOpen) {
                    collapsePanel(true);
                    return true;
                }
                return false;
            }
        });

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX);
                        int dy = (int) (event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        params.x = initialX + dx;
                        params.y = initialY + dy;
                        if (params.x < 0) params.x = 0;
                        if (params.y < 0) params.y = 0;
                        try {
                            windowManager.updateViewLayout(floatView, params);
                        } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            ThemeHelper.triggerHaptic(v);
                            togglePanel();
                        } else {
                            snapToSide(true);
                        }
                        return true;
                }
                return false;
            }
        });

        btnFloatInject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!debounce() || CamMonitor.isBusy()) return;
                ThemeHelper.triggerHaptic(v);
                toggleCamera();
            }
        });
        btnFloatMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!debounce()) return;
                ThemeHelper.triggerHaptic(v);
                final boolean muted = !Prefs.getBool("mic_muted", false);
                Prefs.setBool("mic_muted", muted);
                if (muted) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            RootHelper.run("input keyevent 164");
                        }
                    }).start();
                }
                toast(muted ? "Mic Muted" : "Mic On");
                refreshPanelStatus();
                CamMonitor.updateNotification(WolfFloatService.this);
                CamMonitor.notifyStateChanged(WolfFloatService.this);
            }
        });
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!debounce()) return;
                ThemeHelper.triggerHaptic(v);
                Intent i = new Intent(WolfFloatService.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                i.putExtra("show_welcome", true);
                startActivity(i);
                collapsePanel(false);
            }
        });
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!debounce()) return;
                ThemeHelper.triggerHaptic(v);
                toast("Exiting...");
                MainActivity.killAppCompletely(WolfFloatService.this);
            }
        });
        refreshPanelStatus();
    }

    private void snapToSide(boolean saveAlways) {
        int bubbleW = floatView != null ? floatView.getWidth() : 120;
        if (bubbleW < 80) bubbleW = 120;
        int margin = 16;
        int centerX = params.x + bubbleW / 2;
        boolean right = centerX > screenW / 2;
        int targetX = right ? Math.max(margin, screenW - bubbleW - margin) : margin;
        int maxY = screenH - 200;
        if (params.y > maxY) params.y = maxY;
        if (params.y < 40) params.y = 40;
        params.x = targetX;
        try {
            windowManager.updateViewLayout(floatView, params);
        } catch (Exception ignored) {}
        Prefs.setInt("float_x", params.x);
        Prefs.setInt("float_y", params.y);
        if (saveAlways) {
            LogHelper.log("FLOAT", "Docked " + (right ? "right" : "left") + " x=" + params.x);
        }
    }

    private Button makeBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 8;
        b.setLayoutParams(lp);
        return b;
    }

    private void togglePanel() {
        if (panelOpen) collapsePanel(true);
        else expandPanel();
    }

    private void expandPanel() {
        panelOpen = true;
        panel.setVisibility(View.VISIBLE);
        params.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        try {
            windowManager.updateViewLayout(floatView, params);
        } catch (Exception ignored) {}
        refreshPanelStatus();
    }

    private void collapsePanel(boolean snapIfMiddle) {
        panelOpen = false;
        panel.setVisibility(View.GONE);
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        if (snapIfMiddle) {
            int bubbleW = floatView != null ? Math.max(floatView.getWidth(), 100) : 120;
            int margin = 48;
            boolean nearLeft = params.x < margin + 20;
            boolean nearRight = params.x > screenW - bubbleW - margin - 20;
            if (!nearLeft && !nearRight) {
                snapToSide(true);
            } else {
                Prefs.setInt("float_x", params.x);
                Prefs.setInt("float_y", params.y);
                try {
                    windowManager.updateViewLayout(floatView, params);
                } catch (Exception ignored) {}
            }
        } else {
            try {
                windowManager.updateViewLayout(floatView, params);
            } catch (Exception ignored) {}
        }
    }

    private void toggleCamera() {
        final boolean currentlyActive = CamMonitor.isInjected();
        if (btnFloatInject != null) {
            btnFloatInject.setEnabled(false);
            btnFloatInject.setText(currentlyActive ? "Restoring..." : "Injecting...");
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (currentlyActive) {
                    CamMonitor.stopVirtualCameraBlocking(WolfFloatService.this);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (btnFloatInject != null) btnFloatInject.setEnabled(true);
                            toast("Phone camera restored");
                            refreshPanelStatus();
                            CamMonitor.updateNotification(WolfFloatService.this);
                            CamMonitor.notifyStateChanged(WolfFloatService.this);
                        }
                    });
                } else {
                    boolean useRtmp = Prefs.getBool("use_rtmp", false);
                    String rtmpUrl = Prefs.getString("rtmp_url", "rtmp://127.0.0.1:1935/live/stream");
                    final String err = CamMonitor.startVirtualCameraBlocking(WolfFloatService.this, useRtmp, rtmpUrl);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (btnFloatInject != null) btnFloatInject.setEnabled(true);
                            if (err == null) {
                                toast("Virtual camera ON");
                            } else if ("ROOT_REQUIRED".equals(err)) {
                                toast("Root required");
                            } else if ("NO_MEDIA".equals(err)) {
                                toast("No media — select in Manage");
                            } else if ("INVALID_RTMP".equals(err)) {
                                toast("Invalid RTMP URL");
                            } else {
                                toast("Inject failed — error saved in /storage/emulated/0/wolfcam");
                            }
                            refreshPanelStatus();
                            CamMonitor.updateNotification(WolfFloatService.this);
                            CamMonitor.notifyStateChanged(WolfFloatService.this);
                        }
                    });
                }
            }
        }).start();
    }

    private void refreshPanelStatus() {
        boolean inj = CamMonitor.isInjected();
        boolean muted = Prefs.getBool("mic_muted", false);
        int accent = ThemeHelper.getAccent();

        if (bubble != null) {
            GradientDrawable bBg = new GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{ThemeHelper.getBgCard(), ThemeHelper.getBgPrimary()});
            bBg.setCornerRadius(36f);
            bBg.setStroke(3, inj ? accent : ThemeHelper.withAlpha(accent, 140));
            bubble.setBackgroundDrawable(bBg);
            bubble.setTextColor(accent);
        }

        if (panel != null) {
            GradientDrawable pBg = new GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{ThemeHelper.getBgCard(), ThemeHelper.getBgPrimary()});
            pBg.setCornerRadius(32f);
            pBg.setStroke(2, ThemeHelper.withAlpha(accent, 130));
            panel.setBackgroundDrawable(pBg);
        }

        if (tvFloatStatus != null) {
            tvFloatStatus.setText("Cam: " + (inj ? "VIRTUAL ON" : "Phone") + "  |  Mic: " + (muted ? "Muted" : "On"));
            tvFloatStatus.setTextColor(inj ? accent : Color.parseColor("#94A3B8"));
        }
        if (btnFloatInject != null) {
            btnFloatInject.setText(inj ? "Stop Virtual Cam" : "Start Virtual Cam");
            ThemeHelper.applyButton(btnFloatInject, inj);
        }
        if (btnFloatMute != null) {
            btnFloatMute.setText(muted ? "Unmute Mic" : "Mute Mic");
            ThemeHelper.applyButton(btnFloatMute, muted);
        }
        if (btnOpen != null) {
            ThemeHelper.applySoftButton(btnOpen);
        }
        if (btnExit != null) {
            ThemeHelper.applySoftButton(btnExit);
        }
    }

    private void startMonitor() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!monitoring) return;
                if (!Prefs.getBool("float_button", true)) {
                    stopSelf();
                    return;
                }
                try {
                    if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(60 * 60 * 1000L);
                } catch (Exception ignored) {}
                if (CamMonitor.isInjected()) {
                    CamMonitor.enforceSavedStateInBackground(WolfFloatService.this);
                }
                CamMonitor.updateNotification(WolfFloatService.this);
                refreshPanelStatus();
                handler.postDelayed(this, 5000);
            }
        }, 3000);
    }

    @Override
    public void onDestroy() {
        monitoring = false;
        try {
            if (stateReceiver != null) unregisterReceiver(stateReceiver);
        } catch (Exception ignored) {}
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        if (floatView != null && windowManager != null) {
            try { windowManager.removeView(floatView); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
