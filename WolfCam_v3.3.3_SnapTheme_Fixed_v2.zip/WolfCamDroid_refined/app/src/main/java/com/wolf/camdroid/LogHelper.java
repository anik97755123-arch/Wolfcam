package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogHelper {

    public static final String PUBLIC_LOG_DIR_PATH = "/storage/emulated/0/wolfcam";
    private static File publicLogDir;
    private static File internalLogDir;
    private static String lastErrorFilePath = "";

    public static void init(Context ctx) {
        try {
            if (ctx != null) {
                internalLogDir = new File(ctx.getFilesDir(), "wolfcam_logs");
                if (!internalLogDir.exists()) internalLogDir.mkdirs();
            }
        } catch (Exception ignored) {}

        try {
            publicLogDir = new File(PUBLIC_LOG_DIR_PATH);
            if (!publicLogDir.exists()) {
                boolean ok = publicLogDir.mkdirs();
                if (!ok) {
                    File ext = Environment.getExternalStorageDirectory();
                    if (ext != null) {
                        publicLogDir = new File(ext, "wolfcam");
                        publicLogDir.mkdirs();
                    }
                }
            }
        } catch (Exception ignored) {
            publicLogDir = new File(PUBLIC_LOG_DIR_PATH);
        }
    }

    public static String getLogPath() {
        if (lastErrorFilePath != null && !lastErrorFilePath.isEmpty()) {
            return lastErrorFilePath;
        }
        return PUBLIC_LOG_DIR_PATH;
    }

    public static void log(String tag, String msg) {
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = "[" + ts + "] [" + tag + "] " + (msg != null ? msg : "") + "\n";
        appendToFile("wolfcam_session.txt", line, false);

        if (tag != null) {
            String upper = tag.toUpperCase(Locale.US);
            if (upper.contains("ERR") || upper.contains("FAIL") || (msg != null && msg.toLowerCase(Locale.US).contains("failed"))) {
                writeDetailedError(null, tag, msg, null, null);
            }
        }
    }

    public static void logError(String tag, Throwable e) {
        writeDetailedError(null, tag, e != null ? e.getMessage() : "Exception", null, e);
    }

    public static String writeDetailedError(Context ctx, String tag, String summary, String nativeOutput, Throwable t) {
        try {
            if (ctx != null && internalLogDir == null) {
                init(ctx);
            }
            Date now = new Date();
            String fileStamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(now);
            String readableTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US).format(now);
            final String fileName = "error(" + fileStamp + ").txt";

            StringBuilder sb = new StringBuilder();
            sb.append("================================================================\n");
            sb.append("                 WOLFCAM DROID ERROR REPORT\n");
            sb.append("================================================================\n");
            sb.append("Time Occurred : ").append(readableTime).append("\n");
            sb.append("Error Tag     : ").append(tag != null ? tag : "UNKNOWN").append("\n");
            sb.append("Error Summary : ").append(summary != null ? summary : "N/A").append("\n");
            sb.append("Saved File    : ").append(PUBLIC_LOG_DIR_PATH).append("/").append(fileName).append("\n\n");

            sb.append("---------------- DEVICE & ANDROID ENVIRONMENT ----------------\n");
            sb.append("Manufacturer  : ").append(Build.MANUFACTURER).append("\n");
            sb.append("Brand / Model : ").append(Build.BRAND).append(" / ").append(Build.MODEL).append("\n");
            sb.append("Device / Prod : ").append(Build.DEVICE).append(" / ").append(Build.PRODUCT).append("\n");
            sb.append("Board / HW    : ").append(Build.BOARD).append(" / ").append(Build.HARDWARE).append("\n");
            sb.append("Android Ver   : ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
            if (Build.VERSION.SDK_INT >= 23) {
                sb.append("Security Patch: ").append(Build.VERSION.SECURITY_PATCH).append("\n");
            }
            if (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0) {
                StringBuilder abis = new StringBuilder();
                for (int i = 0; i < Build.SUPPORTED_ABIS.length; i++) {
                    if (i > 0) abis.append(", ");
                    abis.append(Build.SUPPORTED_ABIS[i]);
                }
                sb.append("Supported ABIs: ").append(abis.toString()).append("\n");
            }
            sb.append("Fingerprint   : ").append(Build.FINGERPRINT).append("\n\n");

            sb.append("---------------- APP & MEDIA CONFIGURATION -------------------\n");
            try {
                sb.append("Selected Mode : ").append(Prefs.getBool("use_rtmp", false) ? "RTMP Stream" : "Local Image/Video").append("\n");
                String activeMedia = Prefs.getActiveMedia();
                sb.append("Active Media  : ").append(activeMedia != null && !activeMedia.isEmpty() ? activeMedia : "None").append("\n");
                if (activeMedia != null && !activeMedia.isEmpty() && !activeMedia.startsWith("content://")) {
                    File af = new File(activeMedia);
                    sb.append("Media Exists  : ").append(af.exists()).append(" (").append(af.exists() ? af.length() : 0).append(" bytes)\n");
                }
                if (ctx != null) {
                    File cached = MediaHelper.getCachedMediaFile(ctx);
                    sb.append("Cached MP4    : ").append(cached.getAbsolutePath())
                            .append(" [exists=").append(cached.exists())
                            .append(", size=").append(cached.exists() ? cached.length() : 0).append(" bytes]\n");
                }
                sb.append("Saved Inject  : ").append(Prefs.getBool("camera_injected", false)).append("\n");
                sb.append("Mic Muted     : ").append(Prefs.getBool("mic_muted", false)).append("\n");
            } catch (Exception ignored) {}
            sb.append("\n");

            if (nativeOutput != null && !nativeOutput.trim().isEmpty()) {
                sb.append("---------------- NATIVE COMMAND / HOOK OUTPUT ----------------\n");
                sb.append(nativeOutput.trim()).append("\n\n");
            }

            if (t != null) {
                sb.append("---------------- JAVA EXCEPTION STACK TRACE ------------------\n");
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                t.printStackTrace(pw);
                pw.flush();
                sb.append(sw.toString()).append("\n");
            }

            // Collect live system diagnostics in background if we are not on main thread
            if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
                try {
                    String diag = RootHelper.collectSystemDiagnostics();
                    if (diag != null && !diag.isEmpty()) {
                        sb.append("---------------- ROOT & CAMERASERVER DIAGNOSTICS -------------\n");
                        sb.append(diag).append("\n");
                    }
                } catch (Exception ignored) {}
            }

            sb.append("================================================================\n");
            final String content = sb.toString();
            final String targetPublicPath = PUBLIC_LOG_DIR_PATH + "/" + fileName;
            lastErrorFilePath = targetPublicPath;

            // Write immediately if on background thread, else dispatch write thread
            if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
                writeReportSync(fileName, content, true);
            } else {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String fullContent = content;
                        try {
                            String diag = RootHelper.collectSystemDiagnostics();
                            if (diag != null && !diag.isEmpty()) {
                                fullContent += "\n---------------- ROOT & CAMERASERVER DIAGNOSTICS -------------\n"
                                        + diag + "\n================================================================\n";
                            }
                        } catch (Exception ignored) {}
                        writeReportSync(fileName, fullContent, true);
                    }
                }).start();
            }

            return targetPublicPath;
        } catch (Exception e) {
            Log.e("WolfCamLog", "Failed writing error report", e);
            return PUBLIC_LOG_DIR_PATH;
        }
    }

    private static synchronized void writeReportSync(String fileName, String content, boolean overwrite) {
        File internalFile = null;
        try {
            if (internalLogDir != null) {
                if (!internalLogDir.exists()) internalLogDir.mkdirs();
                internalFile = new File(internalLogDir, fileName);
                writeTextFile(internalFile, content, !overwrite);
            }
        } catch (Exception ignored) {}

        boolean wrotePublicDirect = false;
        try {
            File dir = publicLogDir != null ? publicLogDir : new File(PUBLIC_LOG_DIR_PATH);
            if (!dir.exists()) dir.mkdirs();
            File pubFile = new File(dir, fileName);
            wrotePublicDirect = writeTextFile(pubFile, content, !overwrite);
        } catch (Exception ignored) {}

        // Fallback via root shell if direct write to /storage/emulated/0/wolfcam was blocked by Scoped Storage
        if (!wrotePublicDirect && internalFile != null && internalFile.exists()) {
            try {
                String dst = PUBLIC_LOG_DIR_PATH + "/" + fileName;
                String dst2 = "/sdcard/wolfcam/" + fileName;
                RootHelper.run("mkdir -p '" + PUBLIC_LOG_DIR_PATH + "' /sdcard/wolfcam 2>/dev/null; "
                        + "cp -f '" + internalFile.getAbsolutePath() + "' '" + dst + "' 2>/dev/null || "
                        + "cp -f '" + internalFile.getAbsolutePath() + "' '" + dst2 + "' 2>/dev/null; "
                        + "chmod 666 '" + dst + "' '" + dst2 + "' 2>/dev/null || true");
            } catch (Exception ignored) {}
        }
    }

    private static void appendToFile(final String fileName, final String text, final boolean overwrite) {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            writeReportSync(fileName, text, overwrite);
        } else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    writeReportSync(fileName, text, overwrite);
                }
            }).start();
        }
    }

    private static boolean writeTextFile(File f, String content, boolean append) {
        FileOutputStream fos = null;
        OutputStreamWriter osw = null;
        try {
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            fos = new FileOutputStream(f, append);
            osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(content);
            osw.flush();
            return f.exists() && f.length() > 0;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (osw != null) osw.close(); } catch (Exception ignored) {}
            try { if (fos != null) fos.close(); } catch (Exception ignored) {}
        }
    }
}
