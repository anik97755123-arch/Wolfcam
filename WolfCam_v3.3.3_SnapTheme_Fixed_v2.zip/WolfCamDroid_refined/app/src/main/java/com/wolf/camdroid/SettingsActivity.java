package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    private Button btnTheme;
    private Button btnKillApp;
    private TextView tvDeviceDetails;
    private TextView tvAboutVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        LogHelper.init(this);
        setContentView(R.layout.activity_settings);

        final Switch switchNotification = (Switch) findViewById(R.id.switchNotification);
        final Switch switchPlaySound = (Switch) findViewById(R.id.switchPlaySound);
        final Switch switchMicHook = (Switch) findViewById(R.id.switchMicHook);
        final Switch switchRandomPlay = (Switch) findViewById(R.id.switchRandomPlay);
        final Switch switchPrivateDir = (Switch) findViewById(R.id.switchPrivateDir);
        final Switch switchDisableToast = (Switch) findViewById(R.id.switchDisableToast);
        final Switch switchPhotoFake = (Switch) findViewById(R.id.switchPhotoFake);
        final Switch switchFloatButton = (Switch) findViewById(R.id.switchFloatButton);
        final SeekBar seekVolume = (SeekBar) findViewById(R.id.seekVolume);
        final TextView tvVolumeLabel = (TextView) findViewById(R.id.tvVolumeLabel);
        tvAboutVersion = (TextView) findViewById(R.id.tvAboutVersion);
        tvDeviceDetails = (TextView) findViewById(R.id.tvDeviceDetails);
        btnTheme = (Button) findViewById(R.id.btnTheme);
        View killView = findViewById(R.id.btnKillApp);
        if (killView instanceof Button) {
            btnKillApp = (Button) killView;
        }

        switchNotification.setChecked(Prefs.getBool("notif_control", false));
        switchPlaySound.setChecked(Prefs.getBool("play_sound", false));
        switchMicHook.setChecked(Prefs.getBool("mic_hook", false));
        switchRandomPlay.setChecked(Prefs.getBool("random_play", false));
        switchPrivateDir.setChecked(Prefs.getBool("private_dir", false));
        switchDisableToast.setChecked(Prefs.getBool("disable_toast", false));
        switchPhotoFake.setChecked(Prefs.getBool("photo_fake", false));
        if (switchFloatButton != null) switchFloatButton.setChecked(Prefs.getBool("float_button", true));

        int vol = Prefs.getInt("cast_volume", 80);
        seekVolume.setProgress(vol);
        tvVolumeLabel.setText("Volume: " + vol + "%");

        tvAboutVersion.setText("Version 3.3.3 • Theme: " + ThemeHelper.getThemeName()
                + "\nError Logs: " + LogHelper.PUBLIC_LOG_DIR_PATH + "/error(<time>).txt");

        populateDeviceDetails();
        applyScreenTheme();

        CompoundButton.OnCheckedChangeListener listener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ThemeHelper.triggerHaptic(buttonView);
                String key = null;
                int id = buttonView.getId();
                if (id == R.id.switchNotification) key = "notif_control";
                else if (id == R.id.switchPlaySound) key = "play_sound";
                else if (id == R.id.switchMicHook) key = "mic_hook";
                else if (id == R.id.switchRandomPlay) key = "random_play";
                else if (id == R.id.switchPrivateDir) key = "private_dir";
                else if (id == R.id.switchDisableToast) key = "disable_toast";
                else if (id == R.id.switchPhotoFake) key = "photo_fake";
                else if (id == R.id.switchFloatButton) key = "float_button";

                if (key != null) {
                    Prefs.setBool(key, isChecked);
                    String label = buttonView.getText().toString().split("\n")[0];
                    if (!Prefs.getBool("disable_toast", false) || key.equals("disable_toast")) {
                        Toast.makeText(SettingsActivity.this,
                                label + ": " + (isChecked ? "Enabled" : "Disabled"),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        };

        switchNotification.setOnCheckedChangeListener(listener);
        switchPlaySound.setOnCheckedChangeListener(listener);
        switchMicHook.setOnCheckedChangeListener(listener);
        switchRandomPlay.setOnCheckedChangeListener(listener);
        switchPrivateDir.setOnCheckedChangeListener(listener);
        switchDisableToast.setOnCheckedChangeListener(listener);
        switchPhotoFake.setOnCheckedChangeListener(listener);
        if (switchFloatButton != null) {
            switchFloatButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    ThemeHelper.triggerHaptic(buttonView);
                    Prefs.setBool("float_button", isChecked);
                    try {
                        Intent svc = new Intent(SettingsActivity.this, WolfFloatService.class);
                        if (isChecked) {
                            if (android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(SettingsActivity.this)) {
                                startService(svc);
                            } else {
                                Toast.makeText(SettingsActivity.this, "Grant overlay permission first", Toast.LENGTH_LONG).show();
                                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:" + getPackageName()));
                                startActivity(i);
                            }
                        } else {
                            stopService(svc);
                        }
                    } catch (Exception e) {
                        LogHelper.logError("FLOAT_TOGGLE", e);
                        Toast.makeText(SettingsActivity.this, "Float toggle error", Toast.LENGTH_SHORT).show();
                    }
                    Toast.makeText(SettingsActivity.this,
                            isChecked ? "Floating button: On" : "Floating button: Off",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }

        seekVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvVolumeLabel.setText("Volume: " + progress + "%");
                if (fromUser) Prefs.setInt("cast_volume", progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!Prefs.getBool("disable_toast", false)) {
                    Toast.makeText(SettingsActivity.this,
                            "Cast volume set to " + seekBar.getProgress() + "%",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        findViewById(R.id.navHome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                Intent i = new Intent(SettingsActivity.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });
        findViewById(R.id.navManage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                Intent i = new Intent(SettingsActivity.this, ManageActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });

        tvAboutVersion.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ThemeHelper.triggerHaptic(v);
                try {
                    Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.setData(android.net.Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "Cannot open app settings", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        if (btnTheme != null) {
            btnTheme.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ThemeHelper.triggerHaptic(v);
                    ThemeHelper.showPremiumThemeDialog(SettingsActivity.this, new Runnable() {
                        @Override
                        public void run() {
                            applyScreenTheme();
                            Toast.makeText(SettingsActivity.this,
                                    "Applied theme: " + ThemeHelper.getThemeName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }

        if (btnKillApp != null) {
            btnKillApp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ThemeHelper.triggerHaptic(v);
                    MainActivity.killAppCompletely(SettingsActivity.this);
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyScreenTheme();
    }

    private void applyScreenTheme() {
        ThemeHelper.applyActivityTheme(this, 2);
        if (btnTheme != null) {
            btnTheme.setText("THEME: " + ThemeHelper.getThemeName().toUpperCase());
            ThemeHelper.applyButton(btnTheme, false);
        }
        if (btnKillApp != null) {
            ThemeHelper.applyButton(btnKillApp, true);
        }
        if (tvAboutVersion != null) {
            tvAboutVersion.setText("Version 3.3.3 • Theme: " + ThemeHelper.getThemeName()
                    + "\nError Logs: " + LogHelper.PUBLIC_LOG_DIR_PATH + "/error(<time>).txt");
        }
    }

    private void populateDeviceDetails() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Manufacturer: ").append(Build.MANUFACTURER).append("\n");
        sb.append("Brand: ").append(Build.BRAND).append("\n");
        sb.append("Model: ").append(Build.MODEL).append("\n");
        sb.append("Device: ").append(Build.DEVICE).append("\n");
        sb.append("Product: ").append(Build.PRODUCT).append("\n");
        sb.append("Board / Hardware: ").append(Build.BOARD).append(" / ").append(Build.HARDWARE).append("\n");
        sb.append("Android Version: ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        if (Build.VERSION.SDK_INT >= 23) {
            sb.append("Security Patch: ").append(Build.VERSION.SECURITY_PATCH).append("\n");
        }
        if (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0) {
            sb.append("Primary ABI: ").append(Build.SUPPORTED_ABIS[0]).append("\n");
            if (Build.SUPPORTED_ABIS.length > 1) {
                sb.append("Supported ABIs: ");
                for (int i = 0; i < Build.SUPPORTED_ABIS.length; i++) {
                    if (i > 0) sb.append(", ");
                    sb.append(Build.SUPPORTED_ABIS[i]);
                }
                sb.append("\n");
            }
        }
        sb.append("Log Directory: ").append(LogHelper.PUBLIC_LOG_DIR_PATH).append("\n");
        sb.append("Fingerprint: ").append(Build.FINGERPRINT);
        tvDeviceDetails.setText(sb.toString());

        new Thread(new Runnable() {
            @Override
            public void run() {
                final String compat = RootHelper.detectEnvironmentCompatibility();
                if (compat != null && !compat.isEmpty()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvDeviceDetails.setText(sb.toString() + "\nAuto-Detect: " + compat);
                        }
                    });
                }
            }
        }).start();
    }
}
