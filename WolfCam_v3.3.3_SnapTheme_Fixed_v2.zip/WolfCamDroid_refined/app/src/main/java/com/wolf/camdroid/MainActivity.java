package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends Activity {

    private static final int REQ_STORAGE = 1001;

    private Button btnInject, btnMute, btnPreviewCam;
    private RadioButton rbFile, rbRtmp;
    private TextView tvRootBadge, tvCameraStatus, tvDeviceInfo, tvActiveSource, tvMuteStatus, tvVersionInfo;
    private EditText tvActiveMediaName;

    private boolean isCameraReplaced = false;
    private boolean isMuted = false;
    private boolean rootOk = false;
    private File cachedMediaFile;
    private long lastToastMs = 0;
    private Toast activeToast;
    private BroadcastReceiver stateReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        LogHelper.init(this);
        setContentView(R.layout.activity_main);
        CamMonitor.updateNotification(this);

        btnInject = (Button) findViewById(R.id.btnInject);
        btnMute = (Button) findViewById(R.id.btnMute);
        btnPreviewCam = (Button) findViewById(R.id.btnPreviewCam);
        rbFile = (RadioButton) findViewById(R.id.rbFile);
        rbRtmp = (RadioButton) findViewById(R.id.rbRtmp);
        tvRootBadge = (TextView) findViewById(R.id.tvRootBadge);
        tvCameraStatus = (TextView) findViewById(R.id.tvCameraStatus);
        tvDeviceInfo = (TextView) findViewById(R.id.tvDeviceInfo);
        tvActiveSource = (TextView) findViewById(R.id.tvActiveSource);
        tvMuteStatus = (TextView) findViewById(R.id.tvMuteStatus);
        tvVersionInfo = (TextView) findViewById(R.id.tvVersionInfo);
        tvActiveMediaName = (EditText) findViewById(R.id.tvActiveMediaName);

        cachedMediaFile = MediaHelper.getCachedMediaFile(this);
        tvDeviceInfo.setText("Device: " + RootHelper.deviceSummary());
        tvVersionInfo.setText("WolfCam 3.3.3 • Logs: " + LogHelper.PUBLIC_LOG_DIR_PATH);

        isMuted = Prefs.getBool("mic_muted", false);
        isCameraReplaced = CamMonitor.isInjected();
        boolean useRtmpSaved = Prefs.getBool("use_rtmp", false);
        if (rbRtmp != null && rbFile != null) {
            rbRtmp.setChecked(useRtmpSaved);
            rbFile.setChecked(!useRtmpSaved);
        }

        applyThemeEverywhere();
        updateMuteUI();
        refreshStatus();

        stateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                isMuted = Prefs.getBool("mic_muted", false);
                isCameraReplaced = CamMonitor.isInjected();
                applyThemeEverywhere();
                updateMuteUI();
                refreshStatus();
            }
        };
        try {
            registerReceiver(stateReceiver, new IntentFilter(CamMonitor.ACTION_STATE_CHANGED));
        } catch (Exception ignored) {}

        askPermissions();

        if (getIntent() != null && getIntent().getBooleanExtra("show_welcome", false)) {
            tvRootBadge.post(new Runnable() {
                @Override public void run() { showWelcomeDialog(); }
            });
        }
        Prefs.incLaunchCount();
        if (Prefs.isFirstLaunchDone() && Prefs.getLaunchCount() >= 2) {
            tvRootBadge.postDelayed(new Runnable() {
                @Override
                public void run() {
                    showWelcomeDialog();
                }
            }, 600);
        } else if (!Prefs.isFirstLaunchDone()) {
            tvRootBadge.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Prefs.setFirstLaunchDone();
                }
            }, 3000);
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean hasRoot = RootHelper.hasRoot();
                rootOk = hasRoot;
                CamMonitor.setRootKnown(hasRoot);
                if (hasRoot) {
                    RootHelper.extractAndDeploy(MainActivity.this);
                    RootHelper.detectEnvironmentCompatibility();
                    CamMonitor.enforceSavedStateInBackground(MainActivity.this);
                }
                LogHelper.log("ROOT", hasRoot ? "Root granted" : "Root failed");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasRoot) {
                            tvRootBadge.setText("Root Active");
                            tvRootBadge.setTextColor(ThemeHelper.getAccent());
                            tvRootBadge.setBackgroundDrawable(ThemeHelper.makeBadgeDrawable(ThemeHelper.getAccent()));
                        } else {
                            tvRootBadge.setText("Root Failed");
                            tvRootBadge.setTextColor(0xFFEF4444);
                            tvRootBadge.setBackgroundDrawable(ThemeHelper.makeBadgeDrawable(0xFFEF4444));
                        }
                        refreshStatus();
                    }
                });
            }
        }).start();

        findViewById(R.id.navManage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                try {
                    startActivity(new Intent(MainActivity.this, ManageActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                } catch (Exception e) {
                    LogHelper.writeDetailedError(MainActivity.this, "NAV_MANAGE", e.getMessage(), null, e);
                    showThemedDialog("Error", "Could not open Manage:\n" + e.getMessage());
                }
            }
        });
        findViewById(R.id.navSettings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                try {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                } catch (Exception e) {
                    LogHelper.writeDetailedError(MainActivity.this, "NAV_SETTINGS", e.getMessage(), null, e);
                    showThemedDialog("Error", "Could not open Settings:\n" + e.getMessage());
                }
            }
        });

        RadioGroup rg = (RadioGroup) findViewById(R.id.rgSource);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean rtmp = (checkedId == R.id.rbRtmp);
                Prefs.setBool("use_rtmp", rtmp);
                if (rtmp) {
                    tvActiveMediaName.setText(Prefs.getString("rtmp_url", "rtmp://127.0.0.1:1935/live/stream"));
                } else {
                    String active = Prefs.getActiveMedia();
                    tvActiveMediaName.setText(active.isEmpty() ? "No media selected — go to Manage" : shortName(active));
                }
            }
        });

        btnInject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                if (CamMonitor.isBusy()) {
                    return;
                }
                if (!rootOk) {
                    showNonRootDialog();
                    return;
                }
                if (!CamMonitor.isInjected()) {
                    startVirtualCamera();
                } else {
                    stopVirtualCamera();
                }
            }
        });

        btnMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeHelper.triggerHaptic(v);
                isMuted = !isMuted;
                Prefs.setBool("mic_muted", isMuted);
                updateMuteUI();
                if (rootOk && isMuted) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            RootHelper.run("input keyevent 164");
                        }
                    }).start();
                }
                toast(isMuted ? "Microphone muted" : "Microphone enabled");
                LogHelper.log("MIC", isMuted ? "Muted" : "Unmuted");
                CamMonitor.updateNotification(MainActivity.this);
                CamMonitor.notifyStateChanged(MainActivity.this);
            }
        });

        View btnRefresh = findViewById(R.id.btnRefresh);
        if (btnRefresh != null) {
            ThemeHelper.applySoftButton((Button) btnRefresh);
            btnRefresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ThemeHelper.triggerHaptic(v);
                    isMuted = Prefs.getBool("mic_muted", false);
                    isCameraReplaced = CamMonitor.isInjected();
                    applyThemeEverywhere();
                    updateMuteUI();
                    refreshStatus();
                    CamMonitor.updateNotification(MainActivity.this);
                    CamMonitor.notifyStateChanged(MainActivity.this);
                    toast("Status refreshed");
                }
            });
        }
        View btnGoManage = findViewById(R.id.btnGoManage);
        if (btnGoManage != null) {
            ThemeHelper.applySoftButton((Button) btnGoManage);
            btnGoManage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ThemeHelper.triggerHaptic(v);
                    startActivity(new Intent(MainActivity.this, ManageActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                }
            });
        }

        if (btnPreviewCam != null) {
            btnPreviewCam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ThemeHelper.triggerHaptic(v);
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1003);
                            return;
                        }
                    }
                    try {
                        startActivity(new Intent(MainActivity.this, PreviewActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    } catch (Exception e) {
                        String path = LogHelper.writeDetailedError(MainActivity.this, "PREVIEW_ERR", e.getMessage(), null, e);
                        showThemedDialog("Preview Error", e.getMessage() + "\n\nSaved log:\n" + path);
                    }
                }
            });
        }
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                }, REQ_STORAGE);
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            }
        } catch (Exception e) {
            LogHelper.logError("BATTERY", e);
        }
        tvRootBadge.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(MainActivity.this)) {
                        showThemedDialog("Display over other apps",
                                "WolfCam needs overlay permission for the floating Wolf button.\n\nGrant it on the next screen.");
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } else {
                        startFloatService();
                    }
                } catch (Exception e) {
                    LogHelper.logError("OVERLAY", e);
                }
            }
        }, 1500);
    }

    private void startFloatService() {
        try {
            if (!Prefs.getBool("float_button", true)) {
                stopService(new Intent(this, WolfFloatService.class));
                CamMonitor.updateNotification(this);
                return;
            }
            Intent svc = new Intent(this, WolfFloatService.class);
            startService(svc);
            CamMonitor.updateNotification(this);
        } catch (Exception e) {
            LogHelper.logError("FLOAT_START", e);
        }
    }

    private void updateNotification() {
        CamMonitor.updateNotification(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                LogHelper.init(this);
                toast("Storage permission granted");
            }
        }
    }

    private void applyThemeEverywhere() {
        try {
            ThemeHelper.applyActivityTheme(this, 0);
            ThemeHelper.applyButton(btnInject, isCameraReplaced);
            ThemeHelper.applyButton(btnMute, isMuted);
            if (btnPreviewCam != null) {
                ThemeHelper.applySoftButton(btnPreviewCam);
            }
            View r = findViewById(R.id.btnRefresh);
            if (r instanceof Button) ThemeHelper.applySoftButton((Button) r);
            View m = findViewById(R.id.btnGoManage);
            if (m instanceof Button) ThemeHelper.applySoftButton((Button) m);
            if (isCameraReplaced && tvCameraStatus != null) {
                tvCameraStatus.setTextColor(ThemeHelper.getAccent());
            }
            if (rootOk && tvRootBadge != null) {
                tvRootBadge.setTextColor(ThemeHelper.getAccent());
                tvRootBadge.setBackgroundDrawable(ThemeHelper.makeBadgeDrawable(ThemeHelper.getAccent()));
            }
        } catch (Exception ignored) {}
    }

    private void updateMuteUI() {
        if (isMuted) {
            btnMute.setText("UNMUTE MIC");
            ThemeHelper.applyButton(btnMute, true);
            tvMuteStatus.setText("Mic: Muted");
            tvMuteStatus.setTextColor(0xFFEF4444);
        } else {
            btnMute.setText("MUTE MIC");
            ThemeHelper.applyButton(btnMute, false);
            tvMuteStatus.setText("Mic: Enabled");
            tvMuteStatus.setTextColor(0xFF94A3B8);
        }
    }

    private void showNonRootDialog() {
        String path = LogHelper.writeDetailedError(this, "NON_ROOT",
                "User attempted to inject camera on a device where root access was unavailable.", null, null);
        toast("Root required — log saved to " + path);
        try {
            android.view.View view = android.view.LayoutInflater.from(this).inflate(R.layout.dialog_nonroot, null);
            view.setBackgroundDrawable(ThemeHelper.dialogBg());
            final AlertDialog dialog = new AlertDialog.Builder(this)
                    .setView(view)
                    .setCancelable(true)
                    .create();
            View okBtn = view.findViewById(R.id.btnNonRootOk);
            if (okBtn instanceof Button) {
                ThemeHelper.applyButton((Button) okBtn, false);
            }
            okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialog.show();
            try {
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                }
            } catch (Exception ignored) {}
        } catch (Exception e) {
            showThemedDialog("WolfCam Droid",
                    "Your device is non-rooted.\n\nYou can't replace camera on a non-rooted device.\n\nError log saved to:\n" + path);
        }
    }

    private void showThemedDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
        try {
            dialog.getWindow().setBackgroundDrawable(ThemeHelper.dialogBg());
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ThemeHelper.getAccent());
        } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMuted = Prefs.getBool("mic_muted", false);
        isCameraReplaced = CamMonitor.isInjected();
        applyThemeEverywhere();
        updateMuteUI();
        try {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                startFloatService();
            }
        } catch (Exception ignored) {}

        if (rbRtmp != null && rbRtmp.isChecked()) {
            tvActiveMediaName.setText(Prefs.getString("rtmp_url", "rtmp://127.0.0.1:1935/live/stream"));
        } else {
            String active = Prefs.getActiveMedia();
            if (active != null && !active.isEmpty()) {
                tvActiveMediaName.setText(shortName(active));
                tvActiveSource.setText("Source: " + shortName(active));
            } else {
                tvActiveMediaName.setText("No media selected — go to Manage");
                tvActiveSource.setText("Source: None");
            }
        }
        tvVersionInfo.setText("WolfCam 3.3.3 • Theme: " + ThemeHelper.getThemeName() + "\nLogs: " + LogHelper.PUBLIC_LOG_DIR_PATH);
        refreshStatus();
    }

    private void refreshStatus() {
        isCameraReplaced = CamMonitor.isInjected();
        if (isCameraReplaced) {
            tvCameraStatus.setText("Camera: Virtual (Active)");
            tvCameraStatus.setTextColor(ThemeHelper.getAccent());
            btnInject.setText("PHONE CAMERA");
            ThemeHelper.applyButton(btnInject, true);
            if (btnPreviewCam != null) {
                btnPreviewCam.setVisibility(View.VISIBLE);
                ThemeHelper.applySoftButton(btnPreviewCam);
            }
        } else {
            tvCameraStatus.setText("Camera: Phone (Default)");
            tvCameraStatus.setTextColor(0xFFF8FAFC);
            btnInject.setText("INJECT CAMERA");
            ThemeHelper.applyButton(btnInject, false);
            if (btnPreviewCam != null) {
                btnPreviewCam.setVisibility(View.GONE);
            }
        }
        updateNotification();
    }

    private void startVirtualCamera() {
        final boolean useRtmp = rbRtmp != null && rbRtmp.isChecked();
        final String rtmpOrPath = tvActiveMediaName.getText().toString().trim();
        btnInject.setEnabled(false);
        btnInject.setText("INJECTING...");

        new Thread(new Runnable() {
            @Override
            public void run() {
                final String err = CamMonitor.startVirtualCameraBlocking(MainActivity.this, useRtmp, rtmpOrPath);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btnInject.setEnabled(true);
                        if (err == null) {
                            isCameraReplaced = true;
                            toast("WolfCam Injected!");
                            startFloatService();
                            refreshStatus();
                            CamMonitor.notifyStateChanged(MainActivity.this);
                        } else {
                            refreshStatus();
                            if ("ROOT_REQUIRED".equals(err)) {
                                showNonRootDialog();
                            } else if ("INVALID_RTMP".equals(err)) {
                                toast("Enter a valid RTMP URL");
                            } else if ("NO_MEDIA".equals(err)) {
                                toast("Please select a valid media file from Manage tab first");
                            } else {
                                String detail = CamMonitor.getLastErrorDetail();
                                showThemedDialog("Inject Failed",
                                        (detail != null && !detail.isEmpty())
                                                ? detail
                                                : "Failed to inject camera hook.\nCheck root and /storage/emulated/0/wolfcam/");
                            }
                        }
                    }
                });
            }
        }).start();
    }

    private void stopVirtualCamera() {
        btnInject.setEnabled(false);
        new Thread(new Runnable() {
            @Override
            public void run() {
                CamMonitor.stopVirtualCameraBlocking(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btnInject.setEnabled(true);
                        isCameraReplaced = false;
                        toast("Phone camera restored");
                        refreshStatus();
                        CamMonitor.notifyStateChanged(MainActivity.this);
                    }
                });
            }
        }).start();
    }

    private void toast(String msg) {
        if (Prefs.getBool("disable_toast", false)) return;
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastToastMs < 400) return;
        lastToastMs = now;
        try {
            if (activeToast != null) activeToast.cancel();
            activeToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
            activeToast.show();
        } catch (Exception e) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        }
    }

    private static String shortName(String path) {
        if (path == null || path.isEmpty()) return "None";
        int idx = Math.max(path.lastIndexOf('/'), path.lastIndexOf(':'));
        if (idx >= 0 && idx < path.length() - 1) return path.substring(idx + 1);
        return path.length() > 40 ? path.substring(0, 37) + "..." : path;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("show_welcome", false)) {
            showWelcomeDialog();
        }
    }

    private void showWelcomeDialog() {
        try {
            android.view.LayoutInflater inflater = android.view.LayoutInflater.from(this);
            android.view.View view = inflater.inflate(R.layout.dialog_welcome, null);
            view.setBackgroundDrawable(ThemeHelper.dialogBg());
            final AlertDialog dialog = new AlertDialog.Builder(this)
                    .setView(view)
                    .setCancelable(true)
                    .create();
            View btnCoffee = view.findViewById(R.id.btnCoffee);
            if (btnCoffee instanceof Button) {
                ThemeHelper.applyButton((Button) btnCoffee, false);
            }
            btnCoffee.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://i.postimg.cc/rp7TxQHn/IMG-20261025-WA0004.jpg"));
                        startActivity(i);
                    } catch (Exception e) {
                        toast("Cannot open link");
                    }
                    dialog.dismiss();
                }
            });
            View btnNoThanks = view.findViewById(R.id.btnNoThanks);
            if (btnNoThanks instanceof Button) {
                ThemeHelper.applySoftButton((Button) btnNoThanks);
            }
            btnNoThanks.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialog.show();
            try {
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawable(
                            new ColorDrawable(android.graphics.Color.TRANSPARENT));
                }
            } catch (Exception ignored) {}
        } catch (Exception e) {
            LogHelper.logError("WELCOME", e);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (stateReceiver != null) unregisterReceiver(stateReceiver);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    public static void killAppCompletely(android.content.Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, WolfFloatService.class));
        } catch (Exception ignored) {}
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) ctx.getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancelAll();
        } catch (Exception ignored) {}
        if (ctx instanceof Activity) {
            ((Activity) ctx).finishAffinity();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }

}
