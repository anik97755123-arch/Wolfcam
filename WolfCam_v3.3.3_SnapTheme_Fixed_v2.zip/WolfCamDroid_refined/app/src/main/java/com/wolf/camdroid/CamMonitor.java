package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.io.File;

public class CamMonitor {

    public static final String ACTION_STATE_CHANGED = "com.wolf.camdroid.STATE_CHANGED";
    private static final int NOTIF_ID = 1001;
    private static volatile boolean lastKnownRoot = false;
    private static volatile boolean busyToggling = false;
    private static volatile String lastErrorDetail = "";

    /**
     * Single source of truth for whether Virtual Camera injection is selected by the user.
     * Defaults to false (Phone Camera) and persists across app restarts until user toggles it.
     */
    public static boolean isInjected() {
        return Prefs.getBool("camera_injected", false);
    }

    public static boolean isBusy() {
        return busyToggling;
    }

    public static String getLastErrorDetail() {
        return lastErrorDetail != null ? lastErrorDetail : "";
    }

    public static void setInjected(boolean on) {
        Prefs.setBool("camera_injected", on);
    }

    public static void setInjected(Context ctx, boolean on) {
        Prefs.init(ctx);
        Prefs.setBool("camera_injected", on);
        updateNotification(ctx);
        notifyStateChanged(ctx);
    }

    public static void setRootKnown(boolean rootOk) {
        lastKnownRoot = rootOk;
    }

    public static void notifyStateChanged(Context ctx) {
        if (ctx == null) return;
        try {
            Intent pkgIntent = new Intent(ACTION_STATE_CHANGED);
            pkgIntent.setPackage(ctx.getPackageName());
            ctx.sendBroadcast(pkgIntent);
        } catch (Exception ignored) {}
    }

    /**
     * Starts virtual camera injection and feeder synchronously (call from a background thread).
     * Returns null on success, or an error code ("ROOT_REQUIRED", "INVALID_RTMP", "NO_MEDIA", "INJECT_FAILED").
     */
    public static synchronized String startVirtualCameraBlocking(Context ctx, boolean useRtmp, String rtmpUrl) {
        busyToggling = true;
        lastErrorDetail = "";
        try {
            Prefs.init(ctx);
            LogHelper.init(ctx);
            if (!RootHelper.hasRoot()) {
                lastKnownRoot = false;
                String logFile = LogHelper.writeDetailedError(ctx, "ROOT_REQUIRED",
                        "Root access was denied or unavailable when starting Virtual Camera.", null, null);
                lastErrorDetail = "Root access not granted.\nSaved log: " + logFile;
                return "ROOT_REQUIRED";
            }
            lastKnownRoot = true;
            RootHelper.extractAndDeploy(ctx);

            String feedArg;
            if (useRtmp) {
                if (rtmpUrl == null || rtmpUrl.trim().isEmpty() || !rtmpUrl.trim().startsWith("rtmp")) {
                    return "INVALID_RTMP";
                }
                rtmpUrl = rtmpUrl.trim();
                Prefs.setString("rtmp_url", rtmpUrl);
                Prefs.setBool("use_rtmp", true);
                feedArg = "'" + rtmpUrl.replace("'", "") + "'";
                LogHelper.log("RTMP", "Starting with " + rtmpUrl);
            } else {
                Prefs.setBool("use_rtmp", false);
                if (!MediaHelper.ensureActiveMediaPrepared(ctx)) {
                    String logFile = LogHelper.writeDetailedError(ctx, "NO_MEDIA",
                            "No valid active media file or image-to-MP4 preparation failed.", null, null);
                    lastErrorDetail = "Media preparation failed.\nSaved log: " + logFile;
                    return "NO_MEDIA";
                }
                File cached = MediaHelper.getCachedMediaFile(ctx);
                if (!cached.exists() || cached.length() == 0) {
                    return "NO_MEDIA";
                }
                boolean copied = RootHelper.run("cp -f '" + cached.getAbsolutePath()
                        + "' /data/local/tmp/recam_source.mp4 && chmod 644 /data/local/tmp/recam_source.mp4 && "
                        + "chcon u:object_r:shell_data_file:s0 /data/local/tmp/recam_source.mp4 2>/dev/null || true");
                if (!copied) {
                    LogHelper.log("FILE", "Warning: cp wolf_source.mp4 returned non-zero");
                }
                feedArg = "/data/local/tmp/recam_source.mp4";
                LogHelper.log("FILE", "Starting with local media (" + cached.length() + " bytes)");
            }

            // 1. Kill any old feeder/watcher first so TCP port 127.0.0.1:27183 is free
            RootHelper.run("killall -9 recam_feed recam_watch 2>/dev/null; "
                    + "pkill -9 -f recam_feed 2>/dev/null; "
                    + "pkill -9 -f recam_watch 2>/dev/null || true");

            // 2. Run recam_inject with dynamic SELinux policy & temporary permissive wrap for Android 9-15 compatibility
            String injectCmd = RootHelper.buildDynamicSepolicyCommand()
                    + "OLD_ENF=$(cat /sys/fs/selinux/enforce 2>/dev/null); "
                    + "setenforce 0 2>/dev/null || true; "
                    + "/data/local/tmp/recam_inject 2>&1; "
                    + "RC=$?; "
                    + "if [ \"$OLD_ENF\" = \"1\" ]; then setenforce 1 2>/dev/null || true; fi; "
                    + "echo \"__EXIT_CODE=$RC\"";

            String injOut = RootHelper.runWithOutput(injectCmd);
            boolean injOk = isInjectSuccess(injOut);

            // 3. Auto-recovery: if cameraserver had a stale hook or hung state, reset cameraserver and retry once
            if (!injOk) {
                LogHelper.log("INJECT_RETRY", "Attempt 1 output: " + injOut);
                String resetCmd = "OLD_ENF=$(cat /sys/fs/selinux/enforce 2>/dev/null); "
                        + "setenforce 0 2>/dev/null || true; "
                        + "/data/local/tmp/recam_stop 2>/dev/null || true; ";
                if (injOut != null && (injOut.contains("Restart cameraserver")
                        || injOut.contains("still ACTIVE")
                        || injOut.contains("stand down")
                        || injOut.contains("bad magic")
                        || injOut.contains("timedout"))) {
                    resetCmd += "killall -9 cameraserver 2>/dev/null || true; sleep 1; ";
                }
                resetCmd += RootHelper.buildDynamicSepolicyCommand()
                        + "/data/local/tmp/recam_inject 2>&1; "
                        + "RC=$?; "
                        + "if [ \"$OLD_ENF\" = \"1\" ]; then setenforce 1 2>/dev/null || true; fi; "
                        + "echo \"__EXIT_CODE=$RC\"";
                String retryOut = RootHelper.runWithOutput(resetCmd);
                injOut = "Attempt 1:\n" + injOut + "\n\nAttempt 2 (After Auto-Recovery):\n" + retryOut;
                injOk = isInjectSuccess(retryOut);
            }

            if (!injOk) {
                String reason = parseHumanReadableInjectError(injOut);
                String logPath = LogHelper.writeDetailedError(ctx, "INJECT_FAILED", reason, injOut, null);
                lastErrorDetail = reason + "\n\nFull error log saved to:\n" + logPath;
                return "INJECT_FAILED";
            }

            // 4. Launch recam_feed and recam_watch in a detached subshell so closing su never kills them
            String startFeedCmd = "(nohup /data/local/tmp/recam_feed " + feedArg
                    + " </dev/null >/data/local/tmp/recam_feed.log 2>&1 &) && "
                    + "(nohup /data/local/tmp/recam_watch </dev/null >/dev/null 2>&1 &) && sleep 1";
            RootHelper.run(startFeedCmd);

            setInjected(ctx, true);
            LogHelper.log("INJECT", "Success");
            return null;
        } catch (Exception e) {
            String logPath = LogHelper.writeDetailedError(ctx, "INJECT_EXCEPTION", e.getMessage(), null, e);
            lastErrorDetail = (e.getMessage() != null ? e.getMessage() : "Unexpected error")
                    + "\n\nFull error log saved to:\n" + logPath;
            return "INJECT_FAILED";
        } finally {
            busyToggling = false;
        }
    }

    private static boolean isInjectSuccess(String injOut) {
        if (injOut != null && (injOut.contains("__EXIT_CODE=0") || injOut.contains("Done."))) {
            return true;
        }
        String st = RootHelper.runWithOutput("/data/local/tmp/recam_status 2>/dev/null");
        return st != null && (st.contains("\"active\": true") || st.contains("\"active\":true"));
    }

    private static String parseHumanReadableInjectError(String injOut) {
        if (injOut == null || injOut.trim().isEmpty()) {
            return "Camera hook binary produced no output. Verify root permissions and SELinux.";
        }
        if (injOut.contains("Injector is 64-bit but cameraserver is 32-bit")
                || injOut.contains("is 32bit but Injector is 64bit")) {
            return "Device runs a 32-bit cameraserver process while the hook payload is 64-bit (arm64-v8a).";
        }
        if (injOut.contains("failed validation (wrong ABI?)") || injOut.contains("Emulation only available")) {
            return "Architecture mismatch: cameraserver is running under an incompatible CPU ABI (e.g. x86 emulator without arm64 cameraserver).";
        }
        if (injOut.contains("Could not find process \"cameraserver\"")) {
            return "Could not find running 'cameraserver' system service on this device.";
        }
        if (injOut.contains("Could not resolve the hook target")) {
            return "Could not resolve Camera3OutputStream::returnBufferCheckedLocked in libcameraservice.so on this ROM.";
        }
        if (injOut.contains("CANNOT LINK EXECUTABLE")) {
            return "Dynamic linker error when launching native binary: " + firstMatchingLine(injOut, "CANNOT LINK");
        }
        return "Native hook reported an error:\n" + tailLines(injOut.replace("__EXIT_CODE=1", "").trim(), 5);
    }

    private static String firstMatchingLine(String text, String token) {
        String[] lines = text.split("\n");
        for (String l : lines) {
            if (l.contains(token)) return l.trim();
        }
        return text;
    }

    private static String tailLines(String text, int maxLines) {
        if (text == null || text.isEmpty()) return "";
        String[] lines = text.split("\n");
        int start = Math.max(0, lines.length - maxLines);
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < lines.length; i++) {
            String l = lines[i].trim();
            if (!l.isEmpty()) {
                if (sb.length() > 0) sb.append("\n");
                sb.append(l);
            }
        }
        return sb.toString();
    }

    /**
     * Stops virtual camera injection and restores phone camera synchronously (call from a background thread).
     */
    public static synchronized void stopVirtualCameraBlocking(Context ctx) {
        busyToggling = true;
        try {
            Prefs.init(ctx);
            LogHelper.init(ctx);
            setInjected(ctx, false);

            RootHelper.run("killall -9 recam_watch recam_feed 2>/dev/null; "
                    + "pkill -9 -f recam_watch 2>/dev/null; "
                    + "pkill -9 -f recam_feed 2>/dev/null; "
                    + "OLD_ENF=$(cat /sys/fs/selinux/enforce 2>/dev/null); "
                    + "setenforce 0 2>/dev/null || true; "
                    + "/data/local/tmp/recam_stop 2>/dev/null || true; "
                    + "if [ \"$OLD_ENF\" = \"1\" ]; then setenforce 1 2>/dev/null || true; fi");
            LogHelper.log("STOP", "Phone camera restored");
            updateNotification(ctx);
            notifyStateChanged(ctx);
        } catch (Exception e) {
            LogHelper.logError("STOP", e);
        } finally {
            busyToggling = false;
        }
    }

    /**
     * If injection is currently ON and user changes active media in ManageActivity,
     * hot-reload recam_source.mp4 and restart recam_feed in the background.
     */
    public static void reloadActiveMediaIfInjected(final Context ctx) {
        Prefs.init(ctx);
        if (!isInjected() || Prefs.getBool("use_rtmp", false)) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File cached = MediaHelper.getCachedMediaFile(ctx);
                    if (!cached.exists() || cached.length() == 0) return;
                    RootHelper.run("cp -f '" + cached.getAbsolutePath()
                            + "' /data/local/tmp/recam_source.mp4 && chmod 644 /data/local/tmp/recam_source.mp4; "
                            + "killall -9 recam_feed 2>/dev/null; pkill -9 -f recam_feed 2>/dev/null; "
                            + "(nohup /data/local/tmp/recam_feed /data/local/tmp/recam_source.mp4 </dev/null >/data/local/tmp/recam_feed.log 2>&1 &)");
                } catch (Exception e) {
                    LogHelper.logError("RELOAD_MEDIA", e);
                }
            }
        }).start();
    }

    /**
     * Ensures the underlying system processes match the user's saved preference (camera_injected)
     * without ever overwriting the user's saved selection.
     */
    public static void enforceSavedStateInBackground(final Context ctx) {
        if (busyToggling) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (busyToggling) return;
                try {
                    Prefs.init(ctx);
                    boolean wantInjected = isInjected();
                    if (!RootHelper.hasRoot()) {
                        lastKnownRoot = false;
                        return;
                    }
                    lastKnownRoot = true;
                    if (wantInjected) {
                        String pid = RootHelper.runWithOutput("pidof recam_feed 2>/dev/null");
                        String st = RootHelper.runWithOutput("/data/local/tmp/recam_status 2>/dev/null");
                        boolean hookActive = st != null && (st.contains("\"active\": true") || st.contains("\"active\":true"));
                        boolean feedRunning = pid != null && !pid.trim().isEmpty();
                        if (!hookActive || !feedRunning) {
                            boolean useRtmp = Prefs.getBool("use_rtmp", false);
                            String rtmpUrl = Prefs.getString("rtmp_url", "rtmp://127.0.0.1:1935/live/stream");
                            startVirtualCameraBlocking(ctx, useRtmp, rtmpUrl);
                        }
                    } else {
                        String pid = RootHelper.runWithOutput("pidof recam_feed 2>/dev/null");
                        String st = RootHelper.runWithOutput("/data/local/tmp/recam_status 2>/dev/null");
                        boolean hookActive = st != null && (st.contains("\"active\": true") || st.contains("\"active\":true"));
                        boolean feedRunning = pid != null && !pid.trim().isEmpty();
                        if (hookActive || feedRunning) {
                            RootHelper.run("killall -9 recam_watch recam_feed 2>/dev/null; "
                                    + "pkill -9 -f recam_watch 2>/dev/null; "
                                    + "pkill -9 -f recam_feed 2>/dev/null; "
                                    + "/data/local/tmp/recam_stop 2>/dev/null || true");
                        }
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    public static void updateNotification(Context ctx) {
        try {
            Prefs.init(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            boolean inj = isInjected();
            boolean muted = Prefs.getBool("mic_muted", false);
            boolean root = lastKnownRoot;

            Intent open = new Intent(ctx, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flags |= 67108864; // PendingIntent.FLAG_IMMUTABLE
            }
            PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flags);

            String title = inj ? "WolfCam • Virtual Camera ON" : "WolfCam • Phone Camera";
            String text = "Camera: " + (inj ? "Virtual" : "Phone")
                    + "  |  Mic: " + (muted ? "Muted" : "On")
                    + "  |  Root: " + (root ? "OK" : "Check");

            Notification.Builder b = new Notification.Builder(ctx);
            b.setContentTitle(title)
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .setContentIntent(pi)
                    .setOngoing(inj)
                    .setAutoCancel(!inj)
                    .setOnlyAlertOnce(true);

            if (Build.VERSION.SDK_INT >= 16) {
                b.setPriority(Notification.PRIORITY_LOW);
            }

            nm.notify(NOTIF_ID, b.build());
        } catch (Exception e) {
            LogHelper.logError("NOTIF", e);
        }
    }
}
