package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

public class ThemeHelper {

    public static final String[] NAMES = {
            "Emerald Cyber",
            "Snap Gold",
            "Sapphire Pulse",
            "Amethyst Neon",
            "Crimson Rose",
            "Arctic Cyan",
            "Solar Ember",
            "Teal Aurora",
            "Royal Indigo",
            "Titanium Frost"
    };

    public static final String[] SUBTITLES = {
            "Signature WolfCam neon green on deep obsidian",
            "High-contrast golden yellow on carbon black",
            "Electric cobalt blue on midnight navy",
            "Vibrant ultraviolet purple on cosmic dark",
            "Ruby crimson accent on velvet onyx",
            "Glacial cyan glow on abyssal slate",
            "Warm tactical orange on dark espresso",
            "Bioluminescent teal on deep pine",
            "Deep indigo violet on starlight slate",
            "Clean silver-ice monochrome on pure carbon"
    };

    private static final String[] ACCENT = {
            "#10B981", "#FACC15", "#3B82F6", "#A855F7", "#F43F5E",
            "#06B6D4", "#F97316", "#14B8A6", "#6366F1", "#38BDF8"
    };

    private static final String[] ACCENT_DARK = {
            "#059669", "#CA8A04", "#1D4ED8", "#7E22CE", "#BE123C",
            "#0E7490", "#C2410C", "#0F766E", "#4338CA", "#0284C7"
    };

    private static final String[] BG_PRIMARY = {
            "#070D19", "#0B0B0E", "#070E1E", "#0D0818", "#12080D",
            "#061118", "#110A06", "#061214", "#08091A", "#090B10"
    };

    private static final String[] BG_HEADER = {
            "#0C1628", "#131318", "#0C1830", "#150D26", "#1C0D15",
            "#0A1B26", "#1C110B", "#0A1E20", "#0E1129", "#10141D"
    };

    private static final String[] BG_CARD = {
            "#111E34", "#18181F", "#11203D", "#1C1233", "#26121D",
            "#0F2433", "#24160F", "#0F272A", "#141838", "#151A26"
    };

    private static final String[] BG_INPUT = {
            "#0A1322", "#101015", "#0A1428", "#110B20", "#170B12",
            "#081720", "#170E09", "#09191B", "#0C0E22", "#0D1017"
    };

    private static final String[] BG_NAV = {
            "#040811", "#070709", "#040914", "#080510", "#0B0408",
            "#040B10", "#0B0604", "#040B0C", "#050611", "#05070A"
    };

    public static int themeId() {
        int id = Prefs.getInt("theme_id", 0);
        if (id < 0 || id >= NAMES.length) return 0;
        return id;
    }

    public static String getThemeName() {
        return NAMES[themeId()];
    }

    public static int getAccent() {
        return parse(ACCENT[themeId()]);
    }

    public static int getAccentDark() {
        return parse(ACCENT_DARK[themeId()]);
    }

    public static int getBgPrimary() {
        return parse(BG_PRIMARY[themeId()]);
    }

    public static int getBgHeader() {
        return parse(BG_HEADER[themeId()]);
    }

    public static int getBgCard() {
        return parse(BG_CARD[themeId()]);
    }

    public static int getBgInput() {
        return parse(BG_INPUT[themeId()]);
    }

    public static int getBgNav() {
        return parse(BG_NAV[themeId()]);
    }

    public static int getDanger() {
        return parse("#EF4444");
    }

    public static int getDangerDark() {
        return parse("#B91C1C");
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static int getAccentAlpha(int alpha) {
        return withAlpha(getAccent(), alpha);
    }

    private static int parse(String hex) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return Color.parseColor("#10B981");
        }
    }

    public static void applyButton(Button btn, boolean danger) {
        if (btn == null) return;
        int topColor = danger ? getDanger() : getAccent();
        int botColor = danger ? getDangerDark() : getAccentDark();
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{topColor, botColor});
        gd.setCornerRadius(32f);
        gd.setStroke(2, withAlpha(Color.WHITE, 45));
        btn.setBackgroundDrawable(gd);
        // High-contrast text color for bright yellow/cyan vs dark accents
        int lum = (int) (0.299 * Color.red(topColor) + 0.587 * Color.green(topColor) + 0.114 * Color.blue(topColor));
        btn.setTextColor((!danger && lum > 185) ? Color.parseColor("#090D16") : Color.WHITE);
        if (Build.VERSION.SDK_INT >= 21) {
            btn.setElevation(6f);
        }
        attachPremiumTouchFeedback(btn);
    }

    public static void applySoftButton(Button btn) {
        if (btn == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(30f);
        gd.setColor(getBgInput());
        gd.setStroke(2, getAccentAlpha(165));
        btn.setBackgroundDrawable(gd);
        btn.setTextColor(Color.parseColor("#F8FAFC"));
        if (Build.VERSION.SDK_INT >= 21) {
            btn.setElevation(2f);
        }
        attachPremiumTouchFeedback(btn);
    }

    public static GradientDrawable makeCardDrawable(boolean highlight) {
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{getBgCard(), getBgHeader()});
        gd.setCornerRadius(32f);
        gd.setStroke(highlight ? 3 : 2, getAccentAlpha(highlight ? 160 : 55));
        return gd;
    }

    public static GradientDrawable makeInputDrawable() {
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(24f);
        gd.setColor(getBgInput());
        gd.setStroke(2, getAccentAlpha(95));
        return gd;
    }

    public static GradientDrawable makeBadgeDrawable(int accentColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(50f);
        gd.setColor(withAlpha(accentColor, 36));
        gd.setStroke(2, withAlpha(accentColor, 140));
        return gd;
    }

    public static void applyHeaderText(TextView tv) {
        if (tv != null) tv.setTextColor(getAccent());
    }

    public static GradientDrawable dialogBg() {
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{getBgCard(), getBgPrimary()});
        gd.setCornerRadius(36f);
        gd.setStroke(3, getAccentAlpha(180));
        return gd;
    }

    public static void attachPremiumTouchFeedback(final View view) {
        if (view == null) return;
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start();
                        break;
                }
                return false;
            }
        });
    }

    public static void triggerHaptic(View v) {
        if (v != null) {
            try {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } catch (Exception ignored) {}
        }
    }

    /**
     * Applies the current theme palette across an entire Activity (status/nav bars, background,
     * header, bottom navigation, cards, section titles, badges, inputs, switches, seekbars, and buttons).
     *
     * @param activeTab 0 = Home, 1 = Manage, 2 = Settings
     */
    public static void applyActivityTheme(Activity activity, int activeTab) {
        if (activity == null) return;
        try {
            Prefs.init(activity);
            if (Build.VERSION.SDK_INT >= 21) {
                Window w = activity.getWindow();
                if (w != null) {
                    w.setStatusBarColor(getBgHeader());
                    w.setNavigationBarColor(getBgNav());
                }
            }

            View content = activity.findViewById(android.R.id.content);
            if (content instanceof ViewGroup && ((ViewGroup) content).getChildCount() > 0) {
                View root = ((ViewGroup) content).getChildAt(0);
                if (root != null) {
                    root.setBackgroundColor(getBgPrimary());
                    styleViewTree(root);
                }
            }

            View header = activity.findViewById(R.id.header);
            if (header != null) {
                GradientDrawable hBg = new GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{getBgHeader(), getBgPrimary()});
                hBg.setStroke(1, getAccentAlpha(45));
                header.setBackgroundDrawable(hBg);
            }

            View bottomNav = activity.findViewById(R.id.bottomNav);
            if (bottomNav != null) {
                GradientDrawable nBg = new GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{getBgHeader(), getBgNav()});
                nBg.setStroke(1, getAccentAlpha(50));
                bottomNav.setBackgroundDrawable(nBg);
            }

            styleNavTab(activity.findViewById(R.id.navHome), activeTab == 0);
            styleNavTab(activity.findViewById(R.id.navManage), activeTab == 1);
            styleNavTab(activity.findViewById(R.id.navSettings), activeTab == 2);

            View rootBadge = activity.findViewById(R.id.tvRootBadge);
            if (rootBadge instanceof TextView) {
                int c = ((TextView) rootBadge).getCurrentTextColor();
                rootBadge.setBackgroundDrawable(makeBadgeDrawable(c));
            }

            View totalStats = activity.findViewById(R.id.tvTotalStats);
            if (totalStats instanceof TextView) {
                ((TextView) totalStats).setTextColor(getAccent());
                totalStats.setBackgroundDrawable(makeBadgeDrawable(getAccent()));
            }

            View mediaList = activity.findViewById(R.id.listMedia);
            if (mediaList instanceof ListView) {
                mediaList.setBackgroundDrawable(makeCardDrawable(false));
                ((ListView) mediaList).setDivider(new ColorDrawable(getAccentAlpha(35)));
                ((ListView) mediaList).setDividerHeight(2);
            }
        } catch (Exception ignored) {}
    }

    private static void styleNavTab(View tabView, boolean active) {
        if (!(tabView instanceof ViewGroup)) return;
        ViewGroup vg = (ViewGroup) tabView;
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if (active) {
                    tv.setTextColor(getAccent());
                    tv.setTypeface(Typeface.DEFAULT_BOLD);
                    GradientDrawable pill = new GradientDrawable();
                    pill.setCornerRadius(40f);
                    pill.setColor(getAccentAlpha(32));
                    pill.setStroke(2, getAccentAlpha(110));
                    tv.setPadding(36, 10, 36, 10);
                    tv.setBackgroundDrawable(pill);
                } else {
                    tv.setTextColor(Color.parseColor("#94A3B8"));
                    tv.setTypeface(Typeface.DEFAULT);
                    tv.setPadding(24, 10, 24, 10);
                    tv.setBackgroundDrawable(null);
                }
            }
        }
    }

    private static void styleViewTree(View view) {
        if (view == null) return;
        int id = view.getId();
        if (id == R.id.header || id == R.id.bottomNav) {
            return;
        }

        if (view instanceof EditText) {
            view.setBackgroundDrawable(makeInputDrawable());
            return;
        }

        if (view instanceof SeekBar) {
            if (Build.VERSION.SDK_INT >= 21) {
                ColorStateList tint = ColorStateList.valueOf(getAccent());
                ((SeekBar) view).setProgressTintList(tint);
                ((SeekBar) view).setThumbTintList(tint);
            }
            return;
        }

        if (view instanceof CompoundButton && !(view instanceof Button && !(view instanceof android.widget.RadioButton) && !(view instanceof android.widget.Switch))) {
            if (Build.VERSION.SDK_INT >= 21) {
                int[][] states = new int[][]{
                        new int[]{android.R.attr.state_checked},
                        new int[]{-android.R.attr.state_checked}
                };
                int[] colors = new int[]{getAccent(), Color.parseColor("#64748B")};
                ColorStateList csl = new ColorStateList(states, colors);
                ((CompoundButton) view).setButtonTintList(csl);
                if (view instanceof android.widget.Switch && Build.VERSION.SDK_INT >= 23) {
                    ((android.widget.Switch) view).setThumbTintList(csl);
                    int[] trackColors = new int[]{getAccentAlpha(110), Color.parseColor("#334155")};
                    ((android.widget.Switch) view).setTrackTintList(new ColorStateList(states, trackColors));
                }
            }
            return;
        }

        if (view instanceof TextView && !(view instanceof Button)) {
            TextView tv = (TextView) view;
            CharSequence cs = tv.getText();
            String txt = cs != null ? cs.toString().trim() : "";
            if ("WolfCam Droid".equals(txt)
                    || "STATUS".equals(txt)
                    || "SOURCE".equals(txt)
                    || "INFO".equals(txt)
                    || "GENERAL".equals(txt)
                    || "ADVANCED".equals(txt)
                    || "CAST VOLUME".equals(txt)
                    || "DEVICE INFO".equals(txt)
                    || "ABOUT".equals(txt)
                    || txt.startsWith("MEDIA LIBRARY")
                    || txt.startsWith("Built with love")) {
                tv.setTextColor(getAccent());
            }
            return;
        }

        if (view instanceof LinearLayout) {
            LinearLayout ll = (LinearLayout) view;
            // Detect card containers by checking if parent is the ScrollView's vertical container
            if (ll.getOrientation() == LinearLayout.VERTICAL
                    && ll.getPaddingLeft() >= 12
                    && ll.getParent() instanceof LinearLayout
                    && ((View) ll.getParent()).getParent() instanceof android.widget.ScrollView) {
                ll.setBackgroundDrawable(makeCardDrawable(false));
            }
        }

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                styleViewTree(vg.getChildAt(i));
            }
        }
    }

    /**
     * Displays the refined custom Theme Picker dialog with live color swatches and instant preview.
     */
    public static void showPremiumThemeDialog(final Activity activity, final Runnable onThemeApplied) {
        try {
            View view = android.view.LayoutInflater.from(activity).inflate(R.layout.dialog_theme, null);
            view.setBackgroundDrawable(dialogBg());

            TextView tvTitle = null;
            if (view instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) view;
                for (int i = 0; i < vg.getChildCount(); i++) {
                    View c = vg.getChildAt(i);
                    if (c instanceof TextView) {
                        String t = ((TextView) c).getText().toString();
                        if (t.contains("Pick")) {
                            tvTitle = (TextView) c;
                            tvTitle.setTextColor(getAccent());
                            tvTitle.setText("Choose Your Premium Theme");
                        }
                    }
                }
            }

            final AlertDialog dialog = new AlertDialog.Builder(activity)
                    .setView(view)
                    .setCancelable(true)
                    .create();

            ListView list = (ListView) view.findViewById(R.id.listThemes);
            list.setDivider(new ColorDrawable(getAccentAlpha(35)));
            list.setDividerHeight(2);

            final BaseAdapter adapter = new BaseAdapter() {
                @Override
                public int getCount() {
                    return NAMES.length;
                }

                @Override
                public Object getItem(int position) {
                    return NAMES[position];
                }

                @Override
                public long getItemId(int position) {
                    return position;
                }

                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    Context ctx = parent.getContext();
                    LinearLayout row = new LinearLayout(ctx);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(24, 22, 24, 22);

                    boolean selected = (position == themeId());
                    int acc = parse(ACCENT[position]);
                    int card = parse(BG_CARD[position]);

                    GradientDrawable rowBg = new GradientDrawable();
                    rowBg.setCornerRadius(22f);
                    rowBg.setColor(selected ? withAlpha(acc, 32) : Color.TRANSPARENT);
                    if (selected) {
                        rowBg.setStroke(2, withAlpha(acc, 140));
                    }
                    row.setBackgroundDrawable(rowBg);

                    // Color swatch circle
                    View swatch = new View(ctx);
                    LinearLayout.LayoutParams swLp = new LinearLayout.LayoutParams(56, 56);
                    swLp.rightMargin = 24;
                    swatch.setLayoutParams(swLp);
                    GradientDrawable swDrawable = new GradientDrawable();
                    swDrawable.setShape(GradientDrawable.OVAL);
                    swDrawable.setColor(acc);
                    swDrawable.setStroke(6, card);
                    swatch.setBackgroundDrawable(swDrawable);
                    row.addView(swatch);

                    // Title + Subtitle
                    LinearLayout textCol = new LinearLayout(ctx);
                    textCol.setOrientation(LinearLayout.VERTICAL);
                    LinearLayout.LayoutParams tcLp = new LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    textCol.setLayoutParams(tcLp);

                    TextView tvName = new TextView(ctx);
                    tvName.setText(NAMES[position]);
                    tvName.setTextSize(15f);
                    tvName.setTypeface(Typeface.DEFAULT_BOLD);
                    tvName.setTextColor(selected ? acc : Color.parseColor("#F8FAFC"));
                    textCol.addView(tvName);

                    TextView tvSub = new TextView(ctx);
                    tvSub.setText(SUBTITLES[position]);
                    tvSub.setTextSize(11.5f);
                    tvSub.setTextColor(Color.parseColor("#94A3B8"));
                    textCol.addView(tvSub);

                    row.addView(textCol);

                    // Active badge
                    if (selected) {
                        TextView badge = new TextView(ctx);
                        badge.setText("ACTIVE");
                        badge.setTextSize(10.5f);
                        badge.setTypeface(Typeface.DEFAULT_BOLD);
                        badge.setTextColor(acc);
                        badge.setPadding(20, 8, 20, 8);
                        badge.setBackgroundDrawable(makeBadgeDrawable(acc));
                        row.addView(badge);
                    }

                    return row;
                }
            };

            list.setAdapter(adapter);
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int which, long id) {
                    triggerHaptic(v);
                    Prefs.setInt("theme_id", which);
                    if (onThemeChangedCallback(activity, onThemeApplied)) {
                        // Notify floating service & other screens immediately
                        CamMonitor.notifyStateChanged(activity);
                        try {
                            if (Prefs.getBool("float_button", true)) {
                                activity.startService(new Intent(activity, WolfFloatService.class));
                            }
                        } catch (Exception ignored) {}
                    }
                    dialog.dismiss();
                }
            });

            Button btnCancel = (Button) view.findViewById(R.id.btnThemeCancel);
            if (btnCancel != null) {
                applySoftButton(btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }

            dialog.show();
            try {
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                }
            } catch (Exception ignored) {}
        } catch (Exception e) {
            LogHelper.logError("THEME_DLG", e);
        }
    }

    private static boolean onThemeChangedCallback(Activity activity, Runnable r) {
        try {
            if (r != null) r.run();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
