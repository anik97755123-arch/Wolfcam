package com.wolf.camdroid;

// Made by Wolf — WolfCam Droid

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class RootHelper {

    private static volatile String cachedCompatSummary = null;

    public static boolean hasRoot() {
        String out = runWithOutput("id");
        return out != null && out.contains("uid=0");
    }

    public static boolean run(String command) {
        try {
            Process p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            os.close();
            int code = p.waitFor();
            return code == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static String runWithOutput(String command) {
        try {
            Process p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.writeBytes("(" + command + ") 2>&1\n");
            os.writeBytes("exit\n");
            os.flush();
            os.close();

            InputStream in = p.getInputStream();
            byte[] buf = new byte[4096];
            StringBuilder sb = new StringBuilder();
            int n;
            while ((n = in.read(buf)) > 0) {
                sb.append(new String(buf, 0, n));
            }
            in.close();
            p.waitFor();
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Extracts all recam assets and deploys them to /data/local/tmp, /data/local/recam,
     * and /data/adb/recam, configuring SELinux policies and tool symlinks across Android 9-15+.
     */
    public static void extractAndDeploy(Context ctx) {
        try {
            AssetManager am = ctx.getAssets();
            String[] files = am.list("recam");
            File binDir = new File(ctx.getFilesDir(), "recam");
            if (!binDir.exists()) binDir.mkdirs();

            if (files != null) {
                for (String name : files) {
                    File outFile = new File(binDir, name);
                    InputStream in = am.open("recam/" + name);
                    OutputStream out = new FileOutputStream(outFile);
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    in.close();
                    out.close();
                }
            }

            String path = binDir.getAbsolutePath();
            StringBuilder cmd = new StringBuilder();
            cmd.append("mkdir -p /data/local/tmp /data/local/recam /data/adb/recam '/storage/emulated/0/wolfcam' 2>/dev/null; ");
            cmd.append("chmod 755 /data/local /data/local/tmp /data/local/recam /data/adb/recam 2>/dev/null; ");
            cmd.append("chmod 777 '/storage/emulated/0/wolfcam' 2>/dev/null; ");
            cmd.append("cp -f '").append(path).append("/'* /data/local/tmp/ 2>/dev/null; ");
            cmd.append("cp -f '").append(path).append("/librecam.so' /data/local/recam/librecam.so 2>/dev/null; ");
            cmd.append("cp -f '").append(path).append("/librecam.so' /data/adb/recam/librecam.so 2>/dev/null; ");
            cmd.append("chmod 755 /data/local/tmp/recam* /data/local/tmp/librecam.so /data/local/recam/librecam.so /data/adb/recam/librecam.so 2>/dev/null; ");
            cmd.append("chmod 644 /data/local/tmp/recam.rule 2>/dev/null; ");
            cmd.append("chcon u:object_r:system_lib_file:s0 /data/local/tmp/librecam.so /data/local/recam/librecam.so /data/adb/recam/librecam.so 2>/dev/null || ");
            cmd.append("chcon u:object_r:system_file:s0 /data/local/tmp/librecam.so /data/local/recam/librecam.so 2>/dev/null || true; ");

            // Ensure magiskpolicy can be found at /data/adb/magisk/magiskpolicy if located in /debug_ramdisk or PATH
            cmd.append("MPOL=$(which magiskpolicy 2>/dev/null || find /debug_ramdisk /sbin /system/bin /data/adb -name magiskpolicy 2>/dev/null | head -n 1); ");
            cmd.append("if [ -n \"$MPOL\" ] && [ ! -x /data/adb/magisk/magiskpolicy ]; then mkdir -p /data/adb/magisk 2>/dev/null; ln -sf \"$MPOL\" /data/adb/magisk/magiskpolicy 2>/dev/null; fi; ");

            cmd.append(buildDynamicSepolicyCommand());
            run(cmd.toString());
        } catch (Exception e) {
            LogHelper.logError("DEPLOY", e);
        }
    }

    /**
     * Builds a shell snippet that detects the exact SELinux domains of the root shell and cameraserver
     * and applies live policy rules across Magisk, Kitsune/Magisk Delta, KernelSU, APatch, and SuperSU.
     */
    public static String buildDynamicSepolicyCommand() {
        return "SELF_DOM=$(cat /proc/self/attr/current 2>/dev/null | cut -d: -f3); "
                + "CAM_PID=$(pidof cameraserver 2>/dev/null | awk '{print $1}'); "
                + "CAM_DOM=cameraserver; "
                + "if [ -n \"$CAM_PID\" ]; then CD=$(cat /proc/$CAM_PID/attr/current 2>/dev/null | cut -d: -f3); if [ -n \"$CD\" ]; then CAM_DOM=$CD; fi; fi; "
                + "for TOOL in \"/data/adb/magisk/magiskpolicy\" \"$(which magiskpolicy 2>/dev/null)\" \"/debug_ramdisk/magiskpolicy\" \"/sbin/magiskpolicy\" \"/system/bin/magiskpolicy\" \"/system/bin/supolicy\"; do "
                + "  if [ -n \"$TOOL\" ] && [ -x \"$TOOL\" ]; then "
                + "    \"$TOOL\" --live \"allow $CAM_DOM cameraserver_tmpfs file { read write execute open getattr map }\" 2>/dev/null; "
                + "    \"$TOOL\" --live \"allow $CAM_DOM system_lib_file file { read execute open getattr map }\" 2>/dev/null; "
                + "    \"$TOOL\" --live \"allow $CAM_DOM system_file file { read execute open getattr map }\" 2>/dev/null; "
                + "    \"$TOOL\" --live \"allow $CAM_DOM shell_data_file file { read write execute open getattr map }\" 2>/dev/null; "
                + "    \"$TOOL\" --live \"allow $CAM_DOM system_data_file dir { search read open getattr }\" 2>/dev/null; "
                + "    if [ -n \"$SELF_DOM\" ]; then \"$TOOL\" --live \"allow $SELF_DOM $CAM_DOM process { ptrace sigstop sigchld signal }\" 2>/dev/null; fi; "
                + "    for DOM in magisk su ksu shell untrusted_app; do \"$TOOL\" --live \"allow $DOM $CAM_DOM process { ptrace sigstop sigchld signal }\" 2>/dev/null; done; "
                + "  fi; "
                + "done; "
                + "for KTOOL in /data/adb/ksud /data/adb/ksu/bin/ksud /data/adb/apd /data/adb/ap/bin/apd; do "
                + "  if [ -x \"$KTOOL\" ]; then "
                + "    \"$KTOOL\" sepolicy patch \"allow $CAM_DOM cameraserver_tmpfs file execute\" 2>/dev/null; "
                + "    \"$KTOOL\" sepolicy patch \"allow ksu $CAM_DOM process ptrace\" 2>/dev/null; "
                + "    if [ -n \"$SELF_DOM\" ]; then \"$KTOOL\" sepolicy patch \"allow $SELF_DOM $CAM_DOM process ptrace\" 2>/dev/null; fi; "
                + "  fi; "
                + "done; ";
    }

    /**
     * Collects a detailed diagnostic snapshot of root, SELinux, cameraserver architecture, and recam_status.
     */
    public static String collectSystemDiagnostics() {
        String cmd = "echo \"id: $(id 2>/dev/null)\"; "
                + "echo \"su_ver: $(su -v 2>/dev/null)\"; "
                + "echo \"selinux_enforce: $(cat /sys/fs/selinux/enforce 2>/dev/null || getenforce 2>/dev/null)\"; "
                + "echo \"self_context: $(cat /proc/self/attr/current 2>/dev/null)\"; "
                + "echo \"uname: $(uname -m 2>/dev/null) / $(uname -r 2>/dev/null)\"; "
                + "echo \"native_bridge: $(getprop ro.dalvik.vm.native.bridge 2>/dev/null)\"; "
                + "CPID=$(pidof cameraserver 2>/dev/null | awk '{print $1}'); "
                + "echo \"cameraserver_pid: ${CPID:-none}\"; "
                + "if [ -n \"$CPID\" ]; then "
                + "  echo \"cameraserver_ctx: $(cat /proc/$CPID/attr/current 2>/dev/null)\"; "
                + "  echo \"cameraserver_exe: $(readlink /proc/$CPID/exe 2>/dev/null)\"; "
                + "  echo \"cameraserver_maps_head:\"; grep -E 'cameraserver|libcameraservice|librecam|houdini|ndk_translation' /proc/$CPID/maps 2>/dev/null | head -n 12; "
                + "fi; "
                + "echo \"recam_status: $(/data/local/tmp/recam_status 2>&1)\"; "
                + "if [ -f /data/local/tmp/recam_feed.log ]; then echo \"recam_feed_log:\"; tail -n 20 /data/local/tmp/recam_feed.log 2>/dev/null; fi; "
                + "echo \"logcat_recam:\"; logcat -d -t 40 -s ReCam:* ReCamFeed:* cameraserver:* 2>/dev/null | tail -n 30";
        return runWithOutput(cmd);
    }

    /**
     * Auto-detects camera service architecture (64-bit vs 32-bit, ARM64 vs x86 emulator) and root environment.
     */
    public static String detectEnvironmentCompatibility() {
        if (cachedCompatSummary != null) return cachedCompatSummary;
        try {
            String out = runWithOutput(
                    "CPID=$(pidof cameraserver 2>/dev/null | awk '{print $1}'); "
                    + "UNAME=$(uname -m 2>/dev/null); "
                    + "NB=$(getprop ro.dalvik.vm.native.bridge 2>/dev/null); "
                    + "ENF=$(cat /sys/fs/selinux/enforce 2>/dev/null); "
                    + "EXE=$(readlink /proc/$CPID/exe 2>/dev/null); "
                    + "echo \"PID=$CPID|ARCH=$UNAME|NB=$NB|ENF=$ENF|EXE=$EXE\"");
            if (out != null && !out.isEmpty()) {
                cachedCompatSummary = out;
                return out;
            }
        } catch (Exception ignored) {}
        return "";
    }

    public static String deviceSummary() {
        String abi = (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0)
                ? Build.SUPPORTED_ABIS[0] : Build.CPU_ABI;
        return Build.MANUFACTURER + " " + Build.MODEL
                + " • Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") • " + abi;
    }
}
